-- Seed data for Smart City Assistant

-- Insert sample city metrics
INSERT INTO city_metrics (metric_name, metric_value, unit, location) VALUES
('Energy Consumption', 2.4, 'GWh', 'City Wide'),
('Water Usage', 1.8, 'ML', 'City Wide'),
('Air Quality Index', 42, 'AQI', 'Downtown'),
('Traffic Density', 68, '%', 'Main Corridor'),
('Green Coverage', 34, '%', 'City Wide'),
('Waste Recycled', 78, '%', 'City Wide');

-- Insert sample citizen feedback
INSERT INTO citizen_feedback (citizen_name, category, subject, message, sentiment, status, priority, votes) VALUES
('Sarah Johnson', 'Environment', 'Air Quality Concerns', 'The air quality in downtown has been poor lately. More monitoring needed.', 'negative', 'in-progress', 'high', 12),
('Mike Chen', 'Transportation', 'Great New Bike Lanes', 'The new bike lanes on Main Street are fantastic! Much safer now.', 'positive', 'resolved', 'low', 8),
('Emma Davis', 'Waste Management', 'Recycling Bin Issues', 'Recycling bins in Park District are overflowing. Need more frequent collection.', 'negative', 'pending', 'medium', 15);

-- Insert sample policy documents
INSERT INTO policy_documents (title, description, category, department, status, tags) VALUES
('Sustainable Energy Policy 2024', 'Comprehensive framework for renewable energy adoption', 'Energy', 'Environmental Affairs', 'active', ARRAY['renewable energy', 'carbon neutral', 'solar power']),
('Water Conservation Guidelines', 'Municipal water usage regulations and conservation strategies', 'Water Management', 'Public Works', 'active', ARRAY['water conservation', 'drought management', 'recycling']),
('Green Transportation Initiative', 'Public transport electrification and sustainable mobility framework', 'Transportation', 'Transportation', 'draft', ARRAY['electric vehicles', 'public transport', 'bike lanes']);

-- Insert sample anomalies
INSERT INTO anomalies (type, severity, status, description, location, confidence) VALUES
('Energy Consumption', 'high', 'active', 'Unusual spike in energy consumption detected', 'District 5', 94),
('Water Usage', 'medium', 'investigating', 'Abnormal water usage pattern in residential area', 'Residential Zone B', 87),
('Air Quality', 'low', 'resolved', 'Temporary air quality degradation near industrial area', 'Industrial District', 91);

-- Insert sample KPI forecasts
INSERT INTO kpi_forecasts (kpi_name, current_value, forecast_values, target_value, confidence, forecast_period, scenario) VALUES
('Energy Consumption', 2.4, ARRAY[2.3, 2.2, 2.1, 2.0, 1.9, 1.8], 1.8, 87, '6months', 'current'),
('Water Usage', 1.8, ARRAY[1.7, 1.6, 1.5, 1.4, 1.3, 1.2], 1.2, 92, '6months', 'current'),
('Air Quality Index', 42, ARRAY[40, 38, 35, 33, 30, 28], 25, 78, '6months', 'current');
