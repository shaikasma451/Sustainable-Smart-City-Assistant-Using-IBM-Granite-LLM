"use client"

import { useState } from "react"
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { MessageSquare, Leaf, Bot, Search, Building, Home, User, Bell, LogOut } from "lucide-react"
import { CitizenFeedback } from "../components/citizen-feedback"
import { EcoAdvice } from "../components/eco-advice"
import { ChatAssistant } from "../components/chat-assistant"
import { PolicySearch } from "../components/policy-search"
import { CitizenDashboard } from "./components/citizen-dashboard"
import { CitizenProfile } from "./components/citizen-profile"
import { CitizenNotifications } from "./components/citizen-notifications"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const citizenModules = [
  { id: "dashboard", name: "My Dashboard", icon: Home },
  { id: "feedback", name: "Submit Feedback", icon: MessageSquare },
  { id: "eco-advice", name: "Eco Tips", icon: Leaf },
  { id: "chat", name: "AI Assistant", icon: Bot },
  { id: "policy", name: "Policy Search", icon: Search },
  { id: "profile", name: "My Profile", icon: User },
  { id: "notifications", name: "Notifications", icon: Bell },
]

export default function CitizenPortal() {
  const [activeModule, setActiveModule] = useState("dashboard")
  const [user] = useState({
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    district: "District 5",
    memberSince: "2023",
  })

  const renderModule = () => {
    try {
      switch (activeModule) {
        case "dashboard":
          return <CitizenDashboard />
        case "feedback":
          return <CitizenFeedback userId="citizen-001" userName={user.name} />
        case "eco-advice":
          return <EcoAdvice />
        case "chat":
          return <ChatAssistant userType="citizen" userName={user.name} userId="citizen-001" />
        case "policy":
          return <PolicySearch />
        case "profile":
          return <CitizenProfile />
        case "notifications":
          return <CitizenNotifications />
        default:
          return <CitizenDashboard />
      }
    } catch (error) {
      console.error("Error rendering module:", error)
      return (
        <div className="p-6 text-center">
          <p className="text-red-600">Error loading module. Please try again.</p>
          <button
            onClick={() => setActiveModule("dashboard")}
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
          >
            Return to Dashboard
          </button>
        </div>
      )
    }
  }

  const handleLogout = () => {
    // In a real app, this would handle logout logic
    window.location.href = "/"
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-gradient-to-br from-blue-50 to-green-50">
        <Sidebar className="border-r border-blue-200">
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-green-500 rounded-lg flex items-center justify-center">
                <Building className="w-4 h-4 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg">Citizen Portal</h1>
                <p className="text-xs text-muted-foreground">Smart City Services</p>
              </div>
            </div>

            {/* User Info */}
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="font-medium text-sm">{user.name}</p>
                  <p className="text-xs text-gray-600">{user.district}</p>
                </div>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarMenu>
              {citizenModules.map((module) => (
                <SidebarMenuItem key={module.id}>
                  <SidebarMenuButton
                    onClick={() => setActiveModule(module.id)}
                    isActive={activeModule === module.id}
                    className="w-full justify-start"
                  >
                    <module.icon className="w-4 h-4" />
                    <span>{module.name}</span>
                    {module.id === "notifications" && (
                      <Badge className="ml-auto bg-red-500 text-white text-xs">3</Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>

            {/* Logout Button */}
            <div className="mt-auto p-4">
              <Button
                variant="outline"
                className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 p-6">
          <div className="mb-6">
            <div className="flex items-center gap-4 mb-2">
              <SidebarTrigger />
              <h2 className="text-2xl font-bold text-gray-800">
                {citizenModules.find((m) => m.id === activeModule)?.name}
              </h2>
            </div>
            <p className="text-gray-600">Welcome to your citizen portal, {user.name}</p>
          </div>

          {renderModule()}
        </main>
      </div>
    </SidebarProvider>
  )
}
