"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Bell,
  CheckCircle,
  AlertTriangle,
  Info,
  Calendar,
  MessageSquare,
  Trash2,
  BookMarkedIcon as MarkAsRead,
} from "lucide-react"

const notifications = [
  {
    id: 1,
    type: "alert",
    title: "Air Quality Alert",
    message: "Air quality in your district has improved to 'Good' level",
    timestamp: "2 hours ago",
    read: false,
    category: "Environment",
    priority: "medium",
  },
  {
    id: 2,
    type: "update",
    title: "Waste Collection Schedule Change",
    message: "Your waste collection has been moved to 9:00 AM tomorrow due to route optimization",
    timestamp: "5 hours ago",
    read: false,
    category: "Services",
    priority: "high",
  },
  {
    id: 3,
    type: "achievement",
    title: "New Achievement Unlocked!",
    message: "Congratulations! You've earned the 'Water Guardian' badge for saving 1000L this month",
    timestamp: "1 day ago",
    read: true,
    category: "Achievement",
    priority: "low",
  },
  {
    id: 4,
    type: "event",
    title: "Community Clean-up Event",
    message: "Join us this Saturday at Central Park for our monthly community clean-up event",
    timestamp: "2 days ago",
    read: true,
    category: "Events",
    priority: "medium",
  },
  {
    id: 5,
    type: "feedback",
    title: "Feedback Response",
    message: "Your feedback about bike lane safety has been reviewed and forwarded to the Transportation Department",
    timestamp: "3 days ago",
    read: false,
    category: "Feedback",
    priority: "medium",
  },
]

export function CitizenNotifications() {
  const [notificationList, setNotificationList] = useState(notifications)
  const [selectedTab, setSelectedTab] = useState("all")

  const getNotificationIcon = (type) => {
    switch (type) {
      case "alert":
        return AlertTriangle
      case "achievement":
        return CheckCircle
      case "event":
        return Calendar
      case "feedback":
        return MessageSquare
      default:
        return Info
    }
  }

  const getNotificationColor = (type, priority) => {
    if (priority === "high") return "border-red-200 bg-red-50"
    if (type === "achievement") return "border-green-200 bg-green-50"
    if (type === "alert") return "border-yellow-200 bg-yellow-50"
    return "border-blue-200 bg-blue-50"
  }

  const getPriorityColor = (priority) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const markAsRead = (id) => {
    setNotificationList((prev) => prev.map((notif) => (notif.id === id ? { ...notif, read: true } : notif)))
  }

  const markAllAsRead = () => {
    setNotificationList((prev) => prev.map((notif) => ({ ...notif, read: true })))
  }

  const deleteNotification = (id) => {
    setNotificationList((prev) => prev.filter((notif) => notif.id !== id))
  }

  const filteredNotifications = notificationList.filter((notif) => {
    if (selectedTab === "unread") return !notif.read
    if (selectedTab === "alerts") return notif.type === "alert"
    if (selectedTab === "events") return notif.type === "event"
    return true
  })

  const unreadCount = notificationList.filter((n) => !n.read).length

  return (
    <div className="space-y-6">
      {/* Notification Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Notifications
                {unreadCount > 0 && <Badge className="bg-red-500 text-white">{unreadCount}</Badge>}
              </CardTitle>
              <CardDescription>Stay updated with city services and your activities</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={markAllAsRead}>
                <MarkAsRead className="w-4 h-4 mr-2" />
                Mark All Read
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Notification Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All ({notificationList.length})</TabsTrigger>
          <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedTab} className="space-y-4">
          {filteredNotifications.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <Bell className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No notifications to display</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredNotifications.map((notification) => {
                const IconComponent = getNotificationIcon(notification.type)
                return (
                  <Card
                    key={notification.id}
                    className={`${getNotificationColor(notification.type, notification.priority)} ${
                      !notification.read ? "border-l-4 border-l-blue-500" : ""
                    }`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div
                          className={`p-2 rounded-lg ${
                            notification.priority === "high"
                              ? "bg-red-100"
                              : notification.type === "achievement"
                                ? "bg-green-100"
                                : notification.type === "alert"
                                  ? "bg-yellow-100"
                                  : "bg-blue-100"
                          }`}
                        >
                          <IconComponent
                            className={`w-5 h-5 ${
                              notification.priority === "high"
                                ? "text-red-600"
                                : notification.type === "achievement"
                                  ? "text-green-600"
                                  : notification.type === "alert"
                                    ? "text-yellow-600"
                                    : "text-blue-600"
                            }`}
                          />
                        </div>

                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className={`font-medium ${!notification.read ? "font-bold" : ""}`}>
                                {notification.title}
                              </h4>
                              <p className="text-sm text-gray-700 mt-1">{notification.message}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline" className="text-xs">
                                  {notification.category}
                                </Badge>
                                <Badge className={`text-xs ${getPriorityColor(notification.priority)}`}>
                                  {notification.priority}
                                </Badge>
                                <span className="text-xs text-gray-500">{notification.timestamp}</span>
                              </div>
                            </div>

                            <div className="flex gap-2">
                              {!notification.read && (
                                <Button variant="ghost" size="sm" onClick={() => markAsRead(notification.id)}>
                                  <CheckCircle className="w-4 h-4" />
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteNotification(notification.id)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
