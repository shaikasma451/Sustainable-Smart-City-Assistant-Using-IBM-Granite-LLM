"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Zap,
  Droplets,
  Wind,
  Car,
  TreePine,
  MessageSquare,
  Award,
  Calendar,
  TrendingUp,
  TrendingDown,
  Bell,
  MapPin,
} from "lucide-react"

const personalMetrics = [
  {
    title: "Energy Usage",
    value: "245 kWh",
    change: -8,
    comparison: "12% below district average",
    icon: Zap,
    color: "text-yellow-600",
    bgColor: "bg-yellow-100",
  },
  {
    title: "Water Usage",
    value: "1,240 L",
    change: -15,
    comparison: "5% below district average",
    icon: Droplets,
    color: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    title: "Carbon Footprint",
    value: "2.1 tons",
    change: -20,
    comparison: "18% below city average",
    icon: TreePine,
    color: "text-green-600",
    bgColor: "bg-green-100",
  },
  {
    title: "Eco Score",
    value: "85/100",
    change: 12,
    comparison: "Top 25% in district",
    icon: Award,
    color: "text-purple-600",
    bgColor: "bg-purple-100",
  },
]

const districtInfo = {
  name: "District 5",
  airQuality: 42,
  trafficLevel: "Moderate",
  nextCollection: "Tomorrow, 8:00 AM",
  events: [
    { name: "Community Clean-up", date: "This Saturday", location: "Central Park" },
    { name: "Sustainability Workshop", date: "Next Tuesday", location: "Community Center" },
  ],
}

const recentActivity = [
  {
    type: "feedback",
    title: "Submitted feedback about bike lanes",
    status: "Under Review",
    date: "2 days ago",
  },
  {
    type: "achievement",
    title: "Earned 'Water Saver' badge",
    status: "Completed",
    date: "1 week ago",
  },
  {
    type: "tip",
    title: "Started LED lighting upgrade",
    status: "In Progress",
    date: "2 weeks ago",
  },
]

export function CitizenDashboard() {
  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <Card className="bg-gradient-to-r from-blue-500 to-green-500 text-white">
        <CardContent className="p-6">
          <h3 className="text-2xl font-bold mb-2">Good morning, Sarah!</h3>
          <p className="text-blue-100 mb-4">
            Your eco-friendly actions this month have saved 45kg of CO₂ and $23 in utilities.
          </p>
          <div className="flex gap-4">
            <Button variant="secondary" size="sm">
              <MessageSquare className="w-4 h-4 mr-2" />
              Submit Feedback
            </Button>
            <Button variant="outline" size="sm" className="text-white border-white hover:bg-white hover:text-blue-600">
              View Eco Tips
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Personal Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {personalMetrics.map((metric, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{metric.title}</CardTitle>
              <div className={`p-2 rounded-lg ${metric.bgColor}`}>
                <metric.icon className={`w-4 h-4 ${metric.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-1">{metric.value}</div>
              <div className="flex items-center gap-1 mb-2">
                {metric.change > 0 ? (
                  <TrendingUp className="w-3 h-3 text-green-500" />
                ) : (
                  <TrendingDown className="w-3 h-3 text-red-500" />
                )}
                <span className={`text-xs ${metric.change > 0 ? "text-green-500" : "text-red-500"}`}>
                  {Math.abs(metric.change)}% this month
                </span>
              </div>
              <p className="text-xs text-gray-600">{metric.comparison}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* District Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            {districtInfo.name} Information
          </CardTitle>
          <CardDescription>Current conditions and updates in your area</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Wind className="w-4 h-4 text-green-600" />
                <span className="font-medium">Air Quality</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold">{districtInfo.airQuality}</span>
                <Badge className="bg-green-100 text-green-800">Good</Badge>
              </div>
              <Progress value={75} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4 text-yellow-600" />
                <span className="font-medium">Traffic Level</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold">{districtInfo.trafficLevel}</span>
                <Badge className="bg-yellow-100 text-yellow-800">Normal</Badge>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span className="font-medium">Waste Collection</span>
              </div>
              <p className="text-sm text-gray-600">{districtInfo.nextCollection}</p>
              <Button variant="outline" size="sm">
                <Bell className="w-4 h-4 mr-1" />
                Set Reminder
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Community Events */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Community Events</CardTitle>
          <CardDescription>Join local sustainability initiatives</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {districtInfo.events.map((event, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-medium">{event.name}</h4>
                  <p className="text-sm text-gray-600">
                    {event.date} • {event.location}
                  </p>
                </div>
                <Button variant="outline" size="sm">
                  Join Event
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Your latest interactions and achievements</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div className="flex-1">
                  <p className="font-medium text-sm">{activity.title}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant={activity.status === "Completed" ? "default" : "outline"} className="text-xs">
                      {activity.status}
                    </Badge>
                    <span className="text-xs text-gray-500">{activity.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
