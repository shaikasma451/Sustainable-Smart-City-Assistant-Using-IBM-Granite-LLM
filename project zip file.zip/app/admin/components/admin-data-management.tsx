"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Database,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Archive,
  FileText,
  BarChart3,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Clock,
} from "lucide-react"

const databaseStats = [
  { name: "City Metrics", records: "1.2M", size: "45.2 GB", lastUpdate: "2 min ago", status: "healthy" },
  { name: "Citizen Feedback", records: "89.5K", size: "12.8 GB", lastUpdate: "5 min ago", status: "healthy" },
  { name: "Policy Documents", records: "2.3K", size: "8.9 GB", lastUpdate: "1 hour ago", status: "healthy" },
  { name: "Anomaly Logs", records: "456K", size: "23.1 GB", lastUpdate: "30 sec ago", status: "warning" },
  { name: "User Sessions", records: "3.4M", size: "67.8 GB", lastUpdate: "1 min ago", status: "healthy" },
  { name: "System Logs", records: "12.7M", size: "156.3 GB", lastUpdate: "10 sec ago", status: "healthy" },
]

const backupHistory = [
  {
    id: 1,
    type: "Full Backup",
    date: "2024-01-20 02:00:00",
    size: "234.5 GB",
    duration: "2h 15m",
    status: "completed",
  },
  {
    id: 2,
    type: "Incremental",
    date: "2024-01-19 02:00:00",
    size: "45.2 GB",
    duration: "35m",
    status: "completed",
  },
  {
    id: 3,
    type: "Incremental",
    date: "2024-01-18 02:00:00",
    size: "38.7 GB",
    duration: "28m",
    status: "completed",
  },
  {
    id: 4,
    type: "Full Backup",
    date: "2024-01-17 02:00:00",
    size: "228.9 GB",
    duration: "2h 8m",
    status: "failed",
  },
]

const dataExports = [
  {
    id: 1,
    name: "Monthly Sustainability Report",
    format: "PDF",
    size: "12.4 MB",
    created: "2024-01-20",
    downloads: 45,
    status: "ready",
  },
  {
    id: 2,
    name: "Citizen Feedback Analysis",
    format: "CSV",
    size: "8.9 MB",
    created: "2024-01-19",
    downloads: 23,
    status: "ready",
  },
  {
    id: 3,
    name: "Energy Consumption Data",
    format: "JSON",
    size: "156.7 MB",
    created: "2024-01-18",
    downloads: 12,
    status: "processing",
  },
]

export function AdminDataManagement() {
  const [selectedTable, setSelectedTable] = useState(null)
  const [isBackingUp, setIsBackingUp] = useState(false)

  const getStatusColor = (status) => {
    switch (status) {
      case "healthy":
        return "bg-green-100 text-green-800"
      case "warning":
        return "bg-yellow-100 text-yellow-800"
      case "error":
        return "bg-red-100 text-red-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "failed":
        return "bg-red-100 text-red-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "ready":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case "healthy":
      case "completed":
      case "ready":
        return CheckCircle
      case "warning":
        return AlertTriangle
      case "error":
      case "failed":
        return AlertTriangle
      case "processing":
        return Clock
      default:
        return CheckCircle
    }
  }

  const handleBackup = async (type) => {
    setIsBackingUp(true)
    // Simulate backup process
    setTimeout(() => {
      setIsBackingUp(false)
      alert(`${type} backup initiated successfully!`)
    }, 2000)
  }

  const handleExport = (exportId) => {
    alert(`Downloading export ${exportId}...`)
  }

  const handleDataCleanup = () => {
    if (confirm("Are you sure you want to clean up old data? This action cannot be undone.")) {
      alert("Data cleanup initiated. This may take several minutes.")
    }
  }

  return (
    <div className="space-y-6">
      {/* Database Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Records</p>
                <p className="text-2xl font-bold">18.2M</p>
              </div>
              <Database className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Storage Used</p>
                <p className="text-2xl font-bold">314.1 GB</p>
              </div>
              <Archive className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Last Backup</p>
                <p className="text-2xl font-bold">2h ago</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="tables" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="tables">Database Tables</TabsTrigger>
          <TabsTrigger value="backups">Backups</TabsTrigger>
          <TabsTrigger value="exports">Data Exports</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
        </TabsList>

        <TabsContent value="tables" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                Database Tables
              </CardTitle>
              <CardDescription>Monitor database health and performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {databaseStats.map((table, index) => {
                  const StatusIcon = getStatusIcon(table.status)
                  return (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="p-2 bg-blue-100 rounded-lg">
                              <Database className="w-5 h-5 text-blue-600" />
                            </div>
                            <div>
                              <h4 className="font-medium">{table.name}</h4>
                              <p className="text-sm text-gray-600">
                                {table.records} records • {table.size} • Updated {table.lastUpdate}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(table.status)}>
                              <StatusIcon className="w-3 h-3 mr-1" />
                              {table.status}
                            </Badge>
                            <Button variant="outline" size="sm">
                              <BarChart3 className="w-4 h-4 mr-1" />
                              Analyze
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backups" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Archive className="w-5 h-5" />
                    Backup Management
                  </CardTitle>
                  <CardDescription>Create and manage database backups</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => handleBackup("Incremental")} disabled={isBackingUp}>
                    {isBackingUp ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4 mr-2" />
                    )}
                    Incremental Backup
                  </Button>
                  <Button onClick={() => handleBackup("Full")} disabled={isBackingUp}>
                    {isBackingUp ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Archive className="w-4 h-4 mr-2" />
                    )}
                    Full Backup
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {backupHistory.map((backup) => {
                  const StatusIcon = getStatusIcon(backup.status)
                  return (
                    <Card key={backup.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="p-2 bg-purple-100 rounded-lg">
                              <Archive className="w-5 h-5 text-purple-600" />
                            </div>
                            <div>
                              <h4 className="font-medium">{backup.type}</h4>
                              <p className="text-sm text-gray-600">
                                {backup.date} • {backup.size} • Duration: {backup.duration}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(backup.status)}>
                              <StatusIcon className="w-3 h-3 mr-1" />
                              {backup.status}
                            </Badge>
                            {backup.status === "completed" && (
                              <Button variant="outline" size="sm">
                                <Download className="w-4 h-4 mr-1" />
                                Download
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="exports" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Data Exports
                  </CardTitle>
                  <CardDescription>Generate and download data reports</CardDescription>
                </div>
                <Button>
                  <Upload className="w-4 h-4 mr-2" />
                  Create Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dataExports.map((exportItem) => {
                  const StatusIcon = getStatusIcon(exportItem.status)
                  return (
                    <Card key={exportItem.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className="p-2 bg-green-100 rounded-lg">
                              <FileText className="w-5 h-5 text-green-600" />
                            </div>
                            <div>
                              <h4 className="font-medium">{exportItem.name}</h4>
                              <p className="text-sm text-gray-600">
                                {exportItem.format} • {exportItem.size} • Created {exportItem.created} •{" "}
                                {exportItem.downloads} downloads
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(exportItem.status)}>
                              <StatusIcon className="w-3 h-3 mr-1" />
                              {exportItem.status}
                            </Badge>
                            {exportItem.status === "ready" && (
                              <Button variant="outline" size="sm" onClick={() => handleExport(exportItem.id)}>
                                <Download className="w-4 h-4 mr-1" />
                                Download
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <RefreshCw className="w-5 h-5" />
                Database Maintenance
              </CardTitle>
              <CardDescription>Optimize database performance and manage storage</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="border-blue-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <RefreshCw className="w-5 h-5 text-blue-600" />
                      <h4 className="font-medium">Optimize Tables</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">Optimize database tables for better performance</p>
                    <Button variant="outline" className="w-full">
                      Run Optimization
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-yellow-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Trash2 className="w-5 h-5 text-yellow-600" />
                      <h4 className="font-medium">Data Cleanup</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">Remove old logs and temporary data</p>
                    <Button variant="outline" className="w-full" onClick={handleDataCleanup}>
                      Clean Up Data
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-green-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <BarChart3 className="w-5 h-5 text-green-600" />
                      <h4 className="font-medium">Analyze Performance</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">Generate performance analysis report</p>
                    <Button variant="outline" className="w-full">
                      Generate Report
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-purple-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Calendar className="w-5 h-5 text-purple-600" />
                      <h4 className="font-medium">Schedule Maintenance</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">Set up automated maintenance tasks</p>
                    <Button variant="outline" className="w-full">
                      Configure Schedule
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Storage Usage */}
              <Card>
                <CardHeader>
                  <CardTitle>Storage Usage</CardTitle>
                  <CardDescription>Monitor database storage consumption</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Used Storage</span>
                        <span className="text-sm">314.1 GB / 500 GB</span>
                      </div>
                      <Progress value={62.8} className="h-2" />
                      <p className="text-xs text-gray-600">62.8% of total capacity</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <p className="text-2xl font-bold text-blue-600">156.3 GB</p>
                        <p className="text-sm text-gray-600">System Logs</p>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <p className="text-2xl font-bold text-green-600">67.8 GB</p>
                        <p className="text-sm text-gray-600">User Data</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <p className="text-2xl font-bold text-purple-600">90.0 GB</p>
                        <p className="text-sm text-gray-600">Analytics</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
