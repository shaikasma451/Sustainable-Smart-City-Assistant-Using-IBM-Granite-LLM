"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
} from "recharts"
import { TrendingUp, TrendingDown, Users, Leaf, Zap, Droplets, Car, AlertTriangle } from "lucide-react"

// Sample data for different metrics
const cityMetricsData = [
  { month: "Jan", airQuality: 85, energyUsage: 120, waterUsage: 95, trafficFlow: 78, citizenSatisfaction: 4.2 },
  { month: "Feb", airQuality: 88, energyUsage: 115, waterUsage: 92, trafficFlow: 82, citizenSatisfaction: 4.3 },
  { month: "Mar", airQuality: 92, energyUsage: 108, waterUsage: 88, trafficFlow: 85, citizenSatisfaction: 4.4 },
  { month: "Apr", airQuality: 89, energyUsage: 105, waterUsage: 90, trafficFlow: 88, citizenSatisfaction: 4.2 },
  { month: "May", airQuality: 94, energyUsage: 102, waterUsage: 85, trafficFlow: 90, citizenSatisfaction: 4.5 },
  { month: "Jun", airQuality: 96, energyUsage: 98, waterUsage: 82, trafficFlow: 92, citizenSatisfaction: 4.6 },
]

const feedbackData = [
  { category: "Environment", count: 45, resolved: 38, pending: 7 },
  { category: "Transportation", count: 32, resolved: 28, pending: 4 },
  { category: "Waste Management", count: 28, resolved: 25, pending: 3 },
  { category: "Energy", count: 22, resolved: 18, pending: 4 },
  { category: "Water", count: 18, resolved: 16, pending: 2 },
  { category: "Public Safety", count: 15, resolved: 12, pending: 3 },
]

const departmentPerformance = [
  { name: "Environmental", efficiency: 92, budget: 85, satisfaction: 4.5 },
  { name: "Transportation", efficiency: 88, budget: 78, satisfaction: 4.2 },
  { name: "Utilities", efficiency: 95, budget: 92, satisfaction: 4.6 },
  { name: "Public Safety", efficiency: 90, budget: 88, satisfaction: 4.4 },
  { name: "Infrastructure", efficiency: 85, budget: 82, satisfaction: 4.1 },
]

const energyDistribution = [
  { name: "Renewable", value: 45, color: "#10B981" },
  { name: "Natural Gas", value: 30, color: "#3B82F6" },
  { name: "Coal", value: 15, color: "#EF4444" },
  { name: "Nuclear", value: 10, color: "#8B5CF6" },
]

const COLORS = ["#10B981", "#3B82F6", "#EF4444", "#8B5CF6", "#F59E0B", "#EC4899"]

export function AdminAnalytics() {
  const [selectedTimeframe, setSelectedTimeframe] = useState("6months")
  const [selectedMetric, setSelectedMetric] = useState("all")

  const getMetricIcon = (metric: string) => {
    switch (metric) {
      case "airQuality":
        return <Leaf className="w-4 h-4" />
      case "energyUsage":
        return <Zap className="w-4 h-4" />
      case "waterUsage":
        return <Droplets className="w-4 h-4" />
      case "trafficFlow":
        return <Car className="w-4 h-4" />
      default:
        return <TrendingUp className="w-4 h-4" />
    }
  }

  const getMetricColor = (metric: string) => {
    switch (metric) {
      case "airQuality":
        return "#10B981"
      case "energyUsage":
        return "#F59E0B"
      case "waterUsage":
        return "#3B82F6"
      case "trafficFlow":
        return "#EF4444"
      case "citizenSatisfaction":
        return "#8B5CF6"
      default:
        return "#6B7280"
    }
  }

  const calculateTrend = (data: any[], key: string) => {
    const values = data.map((d) => d[key])
    const firstHalf = values.slice(0, Math.floor(values.length / 2))
    const secondHalf = values.slice(Math.floor(values.length / 2))
    const firstAvg = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length
    const secondAvg = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length
    return ((secondAvg - firstAvg) / firstAvg) * 100
  }

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">City Analytics Dashboard</h2>
          <p className="text-gray-600">Comprehensive analysis of city performance metrics</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1month">Last Month</SelectItem>
              <SelectItem value="3months">Last 3 Months</SelectItem>
              <SelectItem value="6months">Last 6 Months</SelectItem>
              <SelectItem value="1year">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">Export Report</Button>
        </div>
      </div>

      {/* Key Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {[
          { key: "airQuality", label: "Air Quality Index", value: 94, trend: 8.2, icon: Leaf, color: "text-green-600" },
          {
            key: "energyUsage",
            label: "Energy Efficiency",
            value: 98,
            trend: -12.5,
            icon: Zap,
            color: "text-yellow-600",
          },
          {
            key: "waterUsage",
            label: "Water Conservation",
            value: 82,
            trend: -15.3,
            icon: Droplets,
            color: "text-blue-600",
          },
          { key: "trafficFlow", label: "Traffic Efficiency", value: 92, trend: 18.7, icon: Car, color: "text-red-600" },
          {
            key: "citizenSatisfaction",
            label: "Citizen Satisfaction",
            value: 4.6,
            trend: 9.5,
            icon: Users,
            color: "text-purple-600",
          },
        ].map((metric) => (
          <Card key={metric.key}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <metric.icon className={`w-8 h-8 ${metric.color}`} />
                <div className="text-right">
                  <p className="text-2xl font-bold text-gray-900">
                    {metric.key === "citizenSatisfaction" ? metric.value.toFixed(1) : metric.value}
                    {metric.key === "citizenSatisfaction" ? "/5" : "%"}
                  </p>
                  <div className="flex items-center gap-1">
                    {metric.trend > 0 ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                    <span className={`text-sm ${metric.trend > 0 ? "text-green-500" : "text-red-500"}`}>
                      {Math.abs(metric.trend).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-2">{metric.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* City Metrics Trend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>City Performance Trends</CardTitle>
            <CardDescription>Key metrics over time showing city health indicators</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                airQuality: { label: "Air Quality", color: "#10B981" },
                energyUsage: { label: "Energy Usage", color: "#F59E0B" },
                waterUsage: { label: "Water Usage", color: "#3B82F6" },
                trafficFlow: { label: "Traffic Flow", color: "#EF4444" },
                citizenSatisfaction: { label: "Satisfaction", color: "#8B5CF6" },
              }}
              className="h-80"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={cityMetricsData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Line type="monotone" dataKey="airQuality" stroke="#10B981" strokeWidth={2} />
                  <Line type="monotone" dataKey="energyUsage" stroke="#F59E0B" strokeWidth={2} />
                  <Line type="monotone" dataKey="waterUsage" stroke="#3B82F6" strokeWidth={2} />
                  <Line type="monotone" dataKey="trafficFlow" stroke="#EF4444" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Citizen Feedback Analysis */}
        <Card>
          <CardHeader>
            <CardTitle>Citizen Feedback by Category</CardTitle>
            <CardDescription>Feedback volume and resolution rates</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                count: { label: "Total", color: "#3B82F6" },
                resolved: { label: "Resolved", color: "#10B981" },
                pending: { label: "Pending", color: "#F59E0B" },
              }}
              className="h-64"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={feedbackData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Bar dataKey="resolved" fill="#10B981" />
                  <Bar dataKey="pending" fill="#F59E0B" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Energy Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Energy Source Distribution</CardTitle>
            <CardDescription>Current energy mix for the city</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                renewable: { label: "Renewable", color: "#10B981" },
                naturalGas: { label: "Natural Gas", color: "#3B82F6" },
                coal: { label: "Coal", color: "#EF4444" },
                nuclear: { label: "Nuclear", color: "#8B5CF6" },
              }}
              className="h-64"
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={energyDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {energyDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Department Performance */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Department Performance Analysis</CardTitle>
            <CardDescription>Efficiency, budget utilization, and satisfaction scores by department</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer
              config={{
                efficiency: { label: "Efficiency %", color: "#10B981" },
                budget: { label: "Budget Utilization %", color: "#3B82F6" },
                satisfaction: { label: "Satisfaction Score", color: "#8B5CF6" },
              }}
              className="h-64"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={departmentPerformance}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Legend />
                  <Bar dataKey="efficiency" fill="#10B981" />
                  <Bar dataKey="budget" fill="#3B82F6" />
                  <Bar dataKey="satisfaction" fill="#8B5CF6" />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Alerts and Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            AI-Generated Insights & Recommendations
          </CardTitle>
          <CardDescription>Automated analysis and suggested actions based on current data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-medium text-green-700">Positive Trends</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Air quality improved by 8.2% this quarter</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Traffic efficiency up 18.7% with new AI system</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>Citizen satisfaction reached 4.6/5 rating</span>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <h4 className="font-medium text-yellow-700">Areas for Improvement</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span>Energy usage optimization needed in District 3</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span>Increase renewable energy to 50% by Q4</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span>Address pending feedback in Transportation</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
