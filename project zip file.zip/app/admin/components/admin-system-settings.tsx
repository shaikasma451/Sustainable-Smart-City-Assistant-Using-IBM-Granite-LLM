"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Settings, Database, Shield, Bell, Zap, Save, CheckCircle, Server, Globe } from "lucide-react"

export function AdminSystemSettings() {
  const [systemSettings, setSystemSettings] = useState({
    siteName: "Smart City Portal",
    maintenanceMode: false,
    autoBackup: true,
    realTimeUpdates: true,
    debugMode: false,
    maxUsers: 10000,
    sessionTimeout: 30,
    apiRateLimit: 1000,
  })

  const [notificationSettings, setNotificationSettings] = useState({
    emailAlerts: true,
    smsAlerts: false,
    pushNotifications: true,
    slackIntegration: false,
    alertThreshold: 80,
  })

  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: true,
    passwordComplexity: true,
    sessionSecurity: true,
    ipWhitelist: false,
    auditLogging: true,
  })

  const systemStatus = {
    uptime: "99.9%",
    responseTime: "245ms",
    activeUsers: 2847,
    systemLoad: 65,
    memoryUsage: 78,
    diskUsage: 45,
  }

  const handleSaveSettings = (settingsType) => {
    alert(`${settingsType} settings saved successfully!`)
  }

  return (
    <div className="space-y-6">
      {/* System Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">System Uptime</p>
                <p className="text-2xl font-bold text-green-600">{systemStatus.uptime}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Response Time</p>
                <p className="text-2xl font-bold text-blue-600">{systemStatus.responseTime}</p>
              </div>
              <Zap className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Users</p>
                <p className="text-2xl font-bold text-purple-600">{systemStatus.activeUsers.toLocaleString()}</p>
              </div>
              <Globe className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Resources */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Server className="w-5 h-5" />
            System Resources
          </CardTitle>
          <CardDescription>Monitor server performance and resource usage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">System Load</span>
                <span className="text-sm">{systemStatus.systemLoad}%</span>
              </div>
              <Progress value={systemStatus.systemLoad} className="h-2" />
              <Badge
                className={systemStatus.systemLoad > 80 ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}
              >
                {systemStatus.systemLoad > 80 ? "High" : "Normal"}
              </Badge>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Memory Usage</span>
                <span className="text-sm">{systemStatus.memoryUsage}%</span>
              </div>
              <Progress value={systemStatus.memoryUsage} className="h-2" />
              <Badge
                className={systemStatus.memoryUsage > 80 ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}
              >
                {systemStatus.memoryUsage > 80 ? "High" : "Normal"}
              </Badge>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Disk Usage</span>
                <span className="text-sm">{systemStatus.diskUsage}%</span>
              </div>
              <Progress value={systemStatus.diskUsage} className="h-2" />
              <Badge className="bg-green-100 text-green-800">Normal</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                General Settings
              </CardTitle>
              <CardDescription>Configure basic system parameters</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                  <Input
                    id="siteName"
                    value={systemSettings.siteName}
                    onChange={(e) => setSystemSettings((prev) => ({ ...prev, siteName: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxUsers">Maximum Users</Label>
                  <Input
                    id="maxUsers"
                    type="number"
                    value={systemSettings.maxUsers}
                    onChange={(e) =>
                      setSystemSettings((prev) => ({ ...prev, maxUsers: Number.parseInt(e.target.value) }))
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                  <Input
                    id="sessionTimeout"
                    type="number"
                    value={systemSettings.sessionTimeout}
                    onChange={(e) =>
                      setSystemSettings((prev) => ({ ...prev, sessionTimeout: Number.parseInt(e.target.value) }))
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="apiRateLimit">API Rate Limit (requests/hour)</Label>
                  <Input
                    id="apiRateLimit"
                    type="number"
                    value={systemSettings.apiRateLimit}
                    onChange={(e) =>
                      setSystemSettings((prev) => ({ ...prev, apiRateLimit: Number.parseInt(e.target.value) }))
                    }
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="maintenanceMode">Maintenance Mode</Label>
                    <p className="text-sm text-gray-600">Enable to restrict access during updates</p>
                  </div>
                  <Switch
                    id="maintenanceMode"
                    checked={systemSettings.maintenanceMode}
                    onCheckedChange={(checked) => setSystemSettings((prev) => ({ ...prev, maintenanceMode: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="autoBackup">Automatic Backups</Label>
                    <p className="text-sm text-gray-600">Daily automated system backups</p>
                  </div>
                  <Switch
                    id="autoBackup"
                    checked={systemSettings.autoBackup}
                    onCheckedChange={(checked) => setSystemSettings((prev) => ({ ...prev, autoBackup: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="realTimeUpdates">Real-time Updates</Label>
                    <p className="text-sm text-gray-600">Enable live data streaming</p>
                  </div>
                  <Switch
                    id="realTimeUpdates"
                    checked={systemSettings.realTimeUpdates}
                    onCheckedChange={(checked) => setSystemSettings((prev) => ({ ...prev, realTimeUpdates: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="debugMode">Debug Mode</Label>
                    <p className="text-sm text-gray-600">Enable detailed logging for troubleshooting</p>
                  </div>
                  <Switch
                    id="debugMode"
                    checked={systemSettings.debugMode}
                    onCheckedChange={(checked) => setSystemSettings((prev) => ({ ...prev, debugMode: checked }))}
                  />
                </div>
              </div>

              <Button onClick={() => handleSaveSettings("General")} className="w-full">
                <Save className="w-4 h-4 mr-2" />
                Save General Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Security Settings
              </CardTitle>
              <CardDescription>Configure system security and access controls</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="twoFactorAuth">Two-Factor Authentication</Label>
                    <p className="text-sm text-gray-600">Require 2FA for admin accounts</p>
                  </div>
                  <Switch
                    id="twoFactorAuth"
                    checked={securitySettings.twoFactorAuth}
                    onCheckedChange={(checked) => setSecuritySettings((prev) => ({ ...prev, twoFactorAuth: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="passwordComplexity">Password Complexity</Label>
                    <p className="text-sm text-gray-600">Enforce strong password requirements</p>
                  </div>
                  <Switch
                    id="passwordComplexity"
                    checked={securitySettings.passwordComplexity}
                    onCheckedChange={(checked) =>
                      setSecuritySettings((prev) => ({ ...prev, passwordComplexity: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sessionSecurity">Enhanced Session Security</Label>
                    <p className="text-sm text-gray-600">Additional session validation checks</p>
                  </div>
                  <Switch
                    id="sessionSecurity"
                    checked={securitySettings.sessionSecurity}
                    onCheckedChange={(checked) =>
                      setSecuritySettings((prev) => ({ ...prev, sessionSecurity: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="ipWhitelist">IP Whitelist</Label>
                    <p className="text-sm text-gray-600">Restrict admin access to specific IPs</p>
                  </div>
                  <Switch
                    id="ipWhitelist"
                    checked={securitySettings.ipWhitelist}
                    onCheckedChange={(checked) => setSecuritySettings((prev) => ({ ...prev, ipWhitelist: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="auditLogging">Audit Logging</Label>
                    <p className="text-sm text-gray-600">Log all administrative actions</p>
                  </div>
                  <Switch
                    id="auditLogging"
                    checked={securitySettings.auditLogging}
                    onCheckedChange={(checked) => setSecuritySettings((prev) => ({ ...prev, auditLogging: checked }))}
                  />
                </div>
              </div>

              <Button onClick={() => handleSaveSettings("Security")} className="w-full">
                <Save className="w-4 h-4 mr-2" />
                Save Security Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Notification Settings
              </CardTitle>
              <CardDescription>Configure system alerts and notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="emailAlerts">Email Alerts</Label>
                    <p className="text-sm text-gray-600">Send system alerts via email</p>
                  </div>
                  <Switch
                    id="emailAlerts"
                    checked={notificationSettings.emailAlerts}
                    onCheckedChange={(checked) =>
                      setNotificationSettings((prev) => ({ ...prev, emailAlerts: checked }))
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="smsAlerts">SMS Alerts</Label>
                    <p className="text-sm text-gray-600">Send critical alerts via SMS</p>
                  </div>
                  <Switch
                    id="smsAlerts"
                    checked={notificationSettings.smsAlerts}
                    onCheckedChange={(checked) => setNotificationSettings((prev) => ({ ...prev, smsAlerts: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="pushNotifications">Push Notifications</Label>
                    <p className="text-sm text-gray-600">Browser push notifications</p>
                  </div>
                  <Switch
                    id="pushNotifications"
                    checked={notificationSettings.pushNotifications}
                    onCheckedChange={(checked) =>
                      setNotificationSettings((prev) => ({ ...prev, pushNotifications: checked }))
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="alertThreshold">Alert Threshold (%)</Label>
                  <Input
                    id="alertThreshold"
                    type="number"
                    min="0"
                    max="100"
                    value={notificationSettings.alertThreshold}
                    onChange={(e) =>
                      setNotificationSettings((prev) => ({ ...prev, alertThreshold: Number.parseInt(e.target.value) }))
                    }
                  />
                  <p className="text-sm text-gray-600">Trigger alerts when metrics exceed this threshold</p>
                </div>
              </div>

              <Button onClick={() => handleSaveSettings("Notification")} className="w-full">
                <Save className="w-4 h-4 mr-2" />
                Save Notification Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                System Integrations
              </CardTitle>
              <CardDescription>Manage external service integrations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="border-green-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-medium">IBM Watsonx</h4>
                        <p className="text-sm text-gray-600">AI and ML services</p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Connected</Badge>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      Configure
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-blue-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-medium">Pinecone</h4>
                        <p className="text-sm text-gray-600">Vector database</p>
                      </div>
                      <Badge className="bg-blue-100 text-blue-800">Connected</Badge>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      Configure
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-yellow-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-medium">Slack</h4>
                        <p className="text-sm text-gray-600">Team notifications</p>
                      </div>
                      <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      Connect
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-gray-200">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-medium">Webhook</h4>
                        <p className="text-sm text-gray-600">Custom integrations</p>
                      </div>
                      <Badge className="bg-gray-100 text-gray-800">Not Connected</Badge>
                    </div>
                    <Button variant="outline" size="sm" className="w-full">
                      Setup
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
