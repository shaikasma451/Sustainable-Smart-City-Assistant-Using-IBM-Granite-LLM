"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Users, UserPlus, Shield, Edit, Trash2, Ban, CheckCircle } from "lucide-react"

const users = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    role: "Citizen",
    district: "District 5",
    status: "Active",
    joinDate: "2023-01-15",
    lastActive: "2 hours ago",
    feedbackCount: 12,
    ecoScore: 85,
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    email: "m.chen@city.gov",
    role: "Administrator",
    department: "Environmental Affairs",
    status: "Active",
    joinDate: "2022-03-10",
    lastActive: "30 minutes ago",
    clearanceLevel: "Level 3",
  },
  {
    id: 3,
    name: "Emma Davis",
    email: "emma.davis@email.com",
    role: "Citizen",
    district: "District 2",
    status: "Active",
    joinDate: "2023-06-22",
    lastActive: "1 day ago",
    feedbackCount: 8,
    ecoScore: 72,
  },
  {
    id: 4,
    name: "James Wilson",
    email: "j.wilson@city.gov",
    role: "Moderator",
    department: "Public Works",
    status: "Active",
    joinDate: "2022-08-15",
    lastActive: "4 hours ago",
    clearanceLevel: "Level 2",
  },
  {
    id: 5,
    name: "Lisa Rodriguez",
    email: "lisa.rodriguez@email.com",
    role: "Citizen",
    district: "District 1",
    status: "Suspended",
    joinDate: "2023-09-05",
    lastActive: "1 week ago",
    feedbackCount: 3,
    ecoScore: 45,
  },
]

const adminStats = [
  { label: "Total Users", value: "2,847", change: "+12%" },
  { label: "Active Citizens", value: "2,654", change: "+8%" },
  { label: "Administrators", value: "23", change: "+2" },
  { label: "Pending Approvals", value: "15", change: "+5" },
]

export function AdminUserManagement() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRole, setSelectedRole] = useState("All")
  const [selectedStatus, setSelectedStatus] = useState("All")
  const [userList, setUserList] = useState(users)

  const getStatusColor = (status) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800"
      case "Suspended":
        return "bg-red-100 text-red-800"
      case "Pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getRoleColor = (role) => {
    switch (role) {
      case "Administrator":
        return "bg-red-100 text-red-800"
      case "Moderator":
        return "bg-blue-100 text-blue-800"
      case "Citizen":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const handleUserAction = (userId, action) => {
    setUserList((prev) =>
      prev
        .map((user) => {
          if (user.id === userId) {
            switch (action) {
              case "suspend":
                return { ...user, status: "Suspended" }
              case "activate":
                return { ...user, status: "Active" }
              case "delete":
                return null
              default:
                return user
            }
          }
          return user
        })
        .filter(Boolean),
    )

    alert(`User ${action} action completed`)
  }

  const filteredUsers = userList.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesRole = selectedRole === "All" || user.role === selectedRole
    const matchesStatus = selectedStatus === "All" || user.status === selectedStatus
    return matchesSearch && matchesRole && matchesStatus
  })

  return (
    <div className="space-y-6">
      {/* Admin Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {adminStats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
                <Badge className="bg-green-100 text-green-800">{stat.change}</Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users">User Management</TabsTrigger>
          <TabsTrigger value="roles">Role Management</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          {/* Search and Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                User Management
              </CardTitle>
              <CardDescription>Manage citizen accounts and administrator access</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search users by name or email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full"
                  />
                </div>
                <Select value={selectedRole} onValueChange={setSelectedRole}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Roles</SelectItem>
                    <SelectItem value="Citizen">Citizens</SelectItem>
                    <SelectItem value="Moderator">Moderators</SelectItem>
                    <SelectItem value="Administrator">Administrators</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Status</SelectItem>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Suspended">Suspended</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
                <Button>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add User
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Users Table */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b">
                    <tr>
                      <th className="text-left p-4 font-medium">User</th>
                      <th className="text-left p-4 font-medium">Role</th>
                      <th className="text-left p-4 font-medium">Status</th>
                      <th className="text-left p-4 font-medium">Activity</th>
                      <th className="text-left p-4 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="border-b hover:bg-gray-50">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                              <span className="text-white font-medium">
                                {user.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium">{user.name}</p>
                              <p className="text-sm text-gray-600">{user.email}</p>
                              {user.district && <p className="text-xs text-gray-500">{user.district}</p>}
                              {user.department && <p className="text-xs text-gray-500">{user.department}</p>}
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge className={getRoleColor(user.role)}>{user.role}</Badge>
                          {user.clearanceLevel && (
                            <Badge className="ml-2 bg-gray-100 text-gray-800 text-xs">{user.clearanceLevel}</Badge>
                          )}
                        </td>
                        <td className="p-4">
                          <Badge className={getStatusColor(user.status)}>{user.status}</Badge>
                        </td>
                        <td className="p-4">
                          <div className="text-sm">
                            <p>Joined: {user.joinDate}</p>
                            <p className="text-gray-600">Last: {user.lastActive}</p>
                            {user.feedbackCount !== undefined && (
                              <p className="text-gray-600">{user.feedbackCount} feedback</p>
                            )}
                            {user.ecoScore && <p className="text-green-600">Eco: {user.ecoScore}/100</p>}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            {user.status === "Active" ? (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleUserAction(user.id, "suspend")}
                                className="text-yellow-600 hover:text-yellow-700"
                              >
                                <Ban className="w-4 h-4" />
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleUserAction(user.id, "activate")}
                                className="text-green-600 hover:text-green-700"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleUserAction(user.id, "delete")}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Role Management</CardTitle>
              <CardDescription>Configure user roles and permissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="border-green-200">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="w-5 h-5 text-green-600" />
                        <h4 className="font-medium">Citizens</h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-4">Basic access to city services and feedback</p>
                      <ul className="text-xs space-y-1">
                        <li>• Submit feedback</li>
                        <li>• View public data</li>
                        <li>• Access eco-advice</li>
                        <li>• Use AI assistant</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="border-blue-200">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        <h4 className="font-medium">Moderators</h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-4">Manage citizen feedback and content</p>
                      <ul className="text-xs space-y-1">
                        <li>• All citizen permissions</li>
                        <li>• Moderate feedback</li>
                        <li>• Respond to citizens</li>
                        <li>• View analytics</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="border-red-200">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="w-5 h-5 text-red-600" />
                        <h4 className="font-medium">Administrators</h4>
                      </div>
                      <p className="text-sm text-gray-600 mb-4">Full system access and management</p>
                      <ul className="text-xs space-y-1">
                        <li>• All system permissions</li>
                        <li>• User management</li>
                        <li>• System configuration</li>
                        <li>• Data management</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Permission Matrix</CardTitle>
              <CardDescription>Configure detailed permissions for each role</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Permission</th>
                      <th className="text-center p-2">Citizen</th>
                      <th className="text-center p-2">Moderator</th>
                      <th className="text-center p-2">Administrator</th>
                    </tr>
                  </thead>
                  <tbody className="space-y-2">
                    <tr className="border-b">
                      <td className="p-2">View Dashboard</td>
                      <td className="text-center p-2">✓</td>
                      <td className="text-center p-2">✓</td>
                      <td className="text-center p-2">✓</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-2">Submit Feedback</td>
                      <td className="text-center p-2">✓</td>
                      <td className="text-center p-2">✓</td>
                      <td className="text-center p-2">✓</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-2">Moderate Content</td>
                      <td className="text-center p-2">✗</td>
                      <td className="text-center p-2">✓</td>
                      <td className="text-center p-2">✓</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-2">User Management</td>
                      <td className="text-center p-2">✗</td>
                      <td className="text-center p-2">✗</td>
                      <td className="text-center p-2">✓</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-2">System Settings</td>
                      <td className="text-center p-2">✗</td>
                      <td className="text-center p-2">✗</td>
                      <td className="text-center p-2">✓</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
