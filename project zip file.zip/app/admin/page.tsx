"use client"

import { useState } from "react"
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import {
  BarChart3,
  MessageSquare,
  FileText,
  Leaf,
  AlertTriangle,
  TrendingUp,
  Bot,
  Search,
  Users,
  Settings,
  Shield,
  LogOut,
  Database,
  PieChart,
} from "lucide-react"
import { CityHealthDashboard } from "../components/city-health-dashboard"
import { DocumentSummarization } from "../components/document-summarization"
import { EcoAdvice } from "../components/eco-advice"
import { AnomalyDetection } from "../components/anomaly-detection"
import { KPIForecasting } from "../components/kpi-forecasting"
import { ChatAssistant } from "../components/chat-assistant"
import { PolicySearch } from "../components/policy-search"
import { AdminUserManagement } from "./components/admin-user-management"
import { AdminSystemSettings } from "./components/admin-system-settings"
import { AdminDataManagement } from "./components/admin-data-management"
import { AdminAnalytics } from "./components/admin-analytics"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AdminFeedback } from "../components/admin-feedback"

const adminModules = [
  { id: "dashboard", name: "City Health Dashboard", icon: BarChart3 },
  { id: "analytics", name: "Analytics & Reports", icon: PieChart },
  { id: "feedback", name: "Citizen Feedback", icon: MessageSquare },
  { id: "documents", name: "Document Analysis", icon: FileText },
  { id: "eco-advice", name: "Eco Programs", icon: Leaf },
  { id: "anomaly", name: "Anomaly Detection", icon: AlertTriangle },
  { id: "forecasting", name: "KPI Forecasting", icon: TrendingUp },
  { id: "chat", name: "AI Assistant", icon: Bot },
  { id: "policy", name: "Policy Management", icon: Search },
  { id: "users", name: "User Management", icon: Users },
  { id: "data", name: "Data Management", icon: Database },
  { id: "settings", name: "System Settings", icon: Settings },
]

export default function AdminPortal() {
  const [activeModule, setActiveModule] = useState("dashboard")
  const [admin] = useState({
    name: "Dr. Michael Chen",
    role: "City Administrator",
    department: "Environmental Affairs",
    clearanceLevel: "Level 3",
  })

  const renderModule = () => {
    try {
      switch (activeModule) {
        case "dashboard":
          return <CityHealthDashboard />
        case "analytics":
          return <AdminAnalytics />
        case "feedback":
          return <AdminFeedback userId="admin-001" userName={admin.name} />
        case "documents":
          return <DocumentSummarization />
        case "eco-advice":
          return <EcoAdvice />
        case "anomaly":
          return <AnomalyDetection />
        case "forecasting":
          return <KPIForecasting />
        case "chat":
          return <ChatAssistant userType="admin" userName={admin.name} userId="admin-001" />
        case "policy":
          return <PolicySearch />
        case "users":
          return <AdminUserManagement />
        case "data":
          return <AdminDataManagement />
        case "settings":
          return <AdminSystemSettings />
        default:
          return <CityHealthDashboard />
      }
    } catch (error) {
      console.error("Error rendering module:", error)
      return (
        <div className="p-6 text-center">
          <p className="text-red-600">Error loading module. Please try again.</p>
          <button onClick={() => setActiveModule("dashboard")} className="mt-4 px-4 py-2 bg-red-500 text-white rounded">
            Return to Dashboard
          </button>
        </div>
      )
    }
  }

  const handleLogout = () => {
    // In a real app, this would handle logout logic
    window.location.href = "/"
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-gradient-to-br from-gray-50 to-blue-50">
        <Sidebar className="border-r border-gray-200">
          <SidebarHeader className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg">Admin Portal</h1>
                <p className="text-xs text-muted-foreground">City Management</p>
              </div>
            </div>

            {/* Admin Info */}
            <div className="mt-4 p-3 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
                  <Shield className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="font-medium text-sm">{admin.name}</p>
                  <p className="text-xs text-gray-600">{admin.role}</p>
                  <Badge className="text-xs mt-1 bg-red-100 text-red-700">{admin.clearanceLevel}</Badge>
                </div>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarMenu>
              {adminModules.map((module) => (
                <SidebarMenuItem key={module.id}>
                  <SidebarMenuButton
                    onClick={() => setActiveModule(module.id)}
                    isActive={activeModule === module.id}
                    className="w-full justify-start"
                  >
                    <module.icon className="w-4 h-4" />
                    <span>{module.name}</span>
                    {module.id === "anomaly" && <Badge className="ml-auto bg-yellow-500 text-white text-xs">5</Badge>}
                    {module.id === "feedback" && <Badge className="ml-auto bg-blue-500 text-white text-xs">12</Badge>}
                    {module.id === "analytics" && (
                      <Badge className="ml-auto bg-green-500 text-white text-xs">New</Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>

            {/* Logout Button */}
            <div className="mt-auto p-4">
              <Button
                variant="outline"
                className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 p-6">
          <div className="mb-6">
            <div className="flex items-center gap-4 mb-2">
              <SidebarTrigger />
              <h2 className="text-2xl font-bold text-gray-800">
                {adminModules.find((m) => m.id === activeModule)?.name}
              </h2>
              <Badge className="bg-green-100 text-green-800">System Online</Badge>
            </div>
            <p className="text-gray-600">Administrative dashboard for {admin.department}</p>
          </div>

          {renderModule()}
        </main>
      </div>
    </SidebarProvider>
  )
}
