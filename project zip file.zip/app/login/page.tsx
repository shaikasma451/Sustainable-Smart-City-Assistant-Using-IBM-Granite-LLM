"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Building, Users, Shield, Eye, EyeOff, AlertCircle } from "lucide-react"

export default function LoginPage() {
  const [userType, setUserType] = useState<"citizen" | "admin" | null>(null)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  // Demo credentials
  const demoCredentials = {
    citizen: { email: "sarah.johnson@email.com", password: "citizen123" },
    admin: { email: "admin@smartcity.gov", password: "admin123" },
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (!userType) {
      setError("Please select user type")
      setLoading(false)
      return
    }

    const expectedCredentials = demoCredentials[userType]

    if (email === expectedCredentials.email && password === expectedCredentials.password) {
      // Successful login - redirect to appropriate portal
      window.location.href = userType === "citizen" ? "/citizen" : "/admin"
    } else {
      setError("Invalid credentials. Please check your email and password.")
    }

    setLoading(false)
  }

  const handleDemoLogin = (type: "citizen" | "admin") => {
    setUserType(type)
    setEmail(demoCredentials[type].email)
    setPassword(demoCredentials[type].password)
  }

  if (!userType) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-green-50 to-blue-100 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Building className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Smart City Portal</h1>
            <p className="text-gray-600">Choose your portal to continue</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Citizen Login */}
            <Card
              className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-300"
              onClick={() => setUserType("citizen")}
            >
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-2xl">Citizen Login</CardTitle>
                <CardDescription>Access city services and submit feedback</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Submit feedback and reports
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    View city metrics and data
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Chat with AI assistant
                  </div>
                </div>
                <Badge className="w-full justify-center bg-blue-100 text-blue-800 hover:bg-blue-200">
                  Demo: sarah.johnson@email.com
                </Badge>
              </CardContent>
            </Card>

            {/* Admin Login */}
            <Card
              className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-red-300"
              onClick={() => setUserType("admin")}
            >
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-red-600" />
                </div>
                <CardTitle className="text-2xl">Admin Login</CardTitle>
                <CardDescription>City management and administration</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Full city health dashboard
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Manage citizen feedback
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    Advanced analytics & reports
                  </div>
                </div>
                <Badge className="w-full justify-center bg-red-100 text-red-800 hover:bg-red-200">
                  Demo: admin@smartcity.gov
                </Badge>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Button variant="outline" onClick={() => (window.location.href = "/")}>
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-green-50 to-blue-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div
            className={`w-16 h-16 ${userType === "citizen" ? "bg-blue-100" : "bg-red-100"} rounded-full flex items-center justify-center mx-auto mb-4`}
          >
            {userType === "citizen" ? (
              <Users className="w-8 h-8 text-blue-600" />
            ) : (
              <Shield className="w-8 h-8 text-red-600" />
            )}
          </div>
          <CardTitle className="text-2xl">{userType === "citizen" ? "Citizen" : "Admin"} Login</CardTitle>
          <CardDescription>Enter your credentials to access the {userType} portal</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-red-600 text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Signing in..." : "Sign In"}
            </Button>
          </form>

          <div className="mt-6 space-y-2">
            <div className="text-center text-sm text-gray-600 mb-3">Demo Credentials:</div>
            <Button variant="outline" size="sm" className="w-full" onClick={() => handleDemoLogin(userType)}>
              Use Demo {userType === "citizen" ? "Citizen" : "Admin"} Account
            </Button>
          </div>

          <div className="mt-4 text-center">
            <Button variant="ghost" size="sm" onClick={() => setUserType(null)}>
              ← Back to Portal Selection
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
