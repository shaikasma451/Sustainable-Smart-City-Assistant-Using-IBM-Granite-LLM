import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: Request) {
  try {
    const { query } = await req.json()

    const { text: response } = await generateText({
      model: openai("gpt-4o"),
      system:
        "You are a smart city policy assistant. When users ask natural language questions about city policies, provide specific, actionable answers with relevant policy references.",
      prompt: `User question: "${query}"\n\nProvide a comprehensive answer about relevant city policies, regulations, and procedures. Include specific policy names, requirements, and next steps where applicable.`,
    })

    // Mock semantic search results
    const results = [
      {
        id: 1,
        title: "AI Response",
        description: response,
        category: "AI Generated",
        relevanceScore: 100,
        type: "ai_response",
      },
    ]

    return Response.json({ results })
  } catch (error) {
    console.error("Semantic search error:", error)
    return Response.json({ error: "Semantic search failed" }, { status: 500 })
  }
}
