import { NextResponse } from "next/server"

export async function GET() {
  // Simulate system status data
  const systemStatus = {
    uptime: "99.9%",
    responseTime: Math.floor(Math.random() * 100) + 200 + "ms",
    activeUsers: Math.floor(Math.random() * 1000) + 2000,
    systemLoad: Math.floor(Math.random() * 40) + 40,
    memoryUsage: Math.floor(Math.random() * 30) + 60,
    diskUsage: Math.floor(Math.random() * 20) + 40,
    services: {
      database: "healthy",
      api: "healthy",
      ai: "healthy",
      storage: "healthy",
    },
    lastUpdated: new Date().toISOString(),
  }

  return NextResponse.json(systemStatus)
}
