import { NextResponse } from "next/server"

// Mock user data for demonstration
const users = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    role: "Citizen",
    district: "District 5",
    status: "Active",
    joinDate: "2023-01-15",
    lastActive: "2 hours ago",
    feedbackCount: 12,
    ecoScore: 85,
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    email: "m.chen@city.gov",
    role: "Administrator",
    department: "Environmental Affairs",
    status: "Active",
    joinDate: "2022-03-10",
    lastActive: "30 minutes ago",
    clearanceLevel: "Level 3",
  },
]

export async function GET() {
  return NextResponse.json({ users })
}

export async function POST(req: Request) {
  const userData = await req.json()

  const newUser = {
    id: users.length + 1,
    ...userData,
    joinDate: new Date().toISOString().split("T")[0],
    lastActive: "Just now",
    status: "Active",
  }

  users.push(newUser)

  return NextResponse.json({ user: newUser, success: true })
}

export async function PUT(req: Request) {
  const { id, ...updateData } = await req.json()

  const userIndex = users.findIndex((user) => user.id === id)
  if (userIndex !== -1) {
    users[userIndex] = { ...users[userIndex], ...updateData }
    return NextResponse.json({ user: users[userIndex], success: true })
  }

  return NextResponse.json({ error: "User not found" }, { status: 404 })
}

export async function DELETE(req: Request) {
  const { id } = await req.json()

  const userIndex = users.findIndex((user) => user.id === id)
  if (userIndex !== -1) {
    users.splice(userIndex, 1)
    return NextResponse.json({ success: true })
  }

  return NextResponse.json({ error: "User not found" }, { status: 404 })
}
