import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: Request) {
  try {
    const { text } = await req.json()

    const { text: summary } = await generateText({
      model: openai("gpt-4o"),
      system:
        "You are an expert at summarizing documents for city management. Provide concise, actionable summaries that highlight key points, decisions, and recommendations.",
      prompt: `Please summarize the following text, focusing on key insights, important decisions, and actionable recommendations:\n\n${text}`,
    })

    return Response.json({ summary })
  } catch (error) {
    console.error("Summarization error:", error)
    return Response.json({ error: "Failed to generate summary" }, { status: 500 })
  }
}
