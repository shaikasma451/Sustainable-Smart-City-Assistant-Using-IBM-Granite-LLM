import { NextResponse } from "next/server"

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const userId = searchParams.get("userId") || "1"

  // Simulate personalized citizen metrics
  const metrics = {
    energyUsage: {
      current: 245,
      unit: "kWh",
      change: -8,
      comparison: "12% below district average",
    },
    waterUsage: {
      current: 1240,
      unit: "L",
      change: -15,
      comparison: "5% below district average",
    },
    carbonFootprint: {
      current: 2.1,
      unit: "tons",
      change: -20,
      comparison: "18% below city average",
    },
    ecoScore: {
      current: 85,
      unit: "/100",
      change: 12,
      comparison: "Top 25% in district",
    },
    district: {
      name: "District 5",
      airQuality: 42,
      trafficLevel: "Moderate",
      nextCollection: "Tomorrow, 8:00 AM",
    },
  }

  return NextResponse.json(metrics)
}
