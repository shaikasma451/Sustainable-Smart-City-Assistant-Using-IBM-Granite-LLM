export async function POST(req: Request) {
  try {
    const { category, subject, message, priority = "medium", userType = "citizen", userId, userName } = await req.json()

    // Validate required fields
    if (!category || !subject || !message) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      })
    }

    // Simulate feedback submission with AI-powered categorization
    const feedbackId = Math.floor(Math.random() * 10000)

    // AI-powered sentiment analysis (simulated)
    const sentiment =
      message.toLowerCase().includes("great") ||
      message.toLowerCase().includes("excellent") ||
      message.toLowerCase().includes("good")
        ? "positive"
        : message.toLowerCase().includes("bad") ||
            message.toLowerCase().includes("terrible") ||
            message.toLowerCase().includes("awful")
          ? "negative"
          : "neutral"

    // Auto-assign priority based on keywords
    const autoPriority =
      message.toLowerCase().includes("urgent") || message.toLowerCase().includes("emergency")
        ? "high"
        : message.toLowerCase().includes("minor") || message.toLowerCase().includes("suggestion")
          ? "low"
          : priority

    const feedbackItem = {
      id: feedbackId,
      citizen: userName || "Anonymous User",
      category,
      subject,
      message,
      sentiment,
      status: "pending",
      priority: autoPriority,
      timestamp: new Date().toISOString(),
      votes: 0,
      userType,
      userId,
      submittedBy: userId, // Track who submitted this feedback
      aiAnalysis: {
        sentiment,
        suggestedDepartment:
          category === "Environment"
            ? "Environmental Affairs"
            : category === "Transportation"
              ? "Transportation Department"
              : category === "Waste Management"
                ? "Sanitation Department"
                : "General Services",
        estimatedResolutionTime:
          autoPriority === "high" ? "24 hours" : autoPriority === "medium" ? "3-5 days" : "1-2 weeks",
      },
    }

    // In a real app, this would save to database
    console.log("New feedback submitted:", feedbackItem)

    return new Response(
      JSON.stringify({
        success: true,
        message: "Feedback submitted successfully! City administrators will review your submission.",
        feedbackId,
        estimatedResponse: feedbackItem.aiAnalysis.estimatedResolutionTime,
      }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    )
  } catch (error) {
    console.error("Feedback API error:", error)
    return new Response(JSON.stringify({ error: "Failed to submit feedback" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url)
    const userType = url.searchParams.get("userType") || "citizen"
    const userId = url.searchParams.get("userId")
    const category = url.searchParams.get("category")
    const status = url.searchParams.get("status")

    // Simulated feedback data - in real app, fetch from database
    const allFeedback = [
      {
        id: 1,
        citizen: "Sarah Johnson",
        category: "Environment",
        subject: "Air Quality Concerns",
        message: "The air quality in downtown has been poor lately. More monitoring needed.",
        sentiment: "negative",
        status: "in-progress",
        priority: "high",
        timestamp: "2 hours ago",
        votes: 12,
        userType: "citizen",
        submittedBy: "citizen-001",
        aiAnalysis: {
          suggestedDepartment: "Environmental Affairs",
          estimatedResolutionTime: "24 hours",
        },
      },
      {
        id: 2,
        citizen: "Mike Chen",
        category: "Transportation",
        subject: "Great New Bike Lanes",
        message: "The new bike lanes on Main Street are fantastic! Much safer now.",
        sentiment: "positive",
        status: "resolved",
        priority: "low",
        timestamp: "5 hours ago",
        votes: 8,
        userType: "citizen",
        submittedBy: "citizen-002",
        aiAnalysis: {
          suggestedDepartment: "Transportation Department",
          estimatedResolutionTime: "1-2 weeks",
        },
      },
      {
        id: 3,
        citizen: "Emma Davis",
        category: "Waste Management",
        subject: "Recycling Bin Issues",
        message: "Recycling bins in Park District are overflowing. Need more frequent collection.",
        sentiment: "negative",
        status: "pending",
        priority: "medium",
        timestamp: "1 day ago",
        votes: 15,
        userType: "citizen",
        submittedBy: "citizen-003",
        aiAnalysis: {
          suggestedDepartment: "Sanitation Department",
          estimatedResolutionTime: "3-5 days",
        },
      },
      {
        id: 4,
        citizen: "Current User",
        category: "Environment",
        subject: "Street Light Issue",
        message: "The street light on Oak Street has been flickering for weeks.",
        sentiment: "negative",
        status: "pending",
        priority: "medium",
        timestamp: "3 days ago",
        votes: 2,
        userType: "citizen",
        submittedBy: "citizen-001", // This matches current user
        aiAnalysis: {
          suggestedDepartment: "Public Works",
          estimatedResolutionTime: "3-5 days",
        },
      },
    ]

    let filteredFeedback = []

    if (userType === "citizen") {
      // Citizens can only see their own submitted feedback
      filteredFeedback = allFeedback.filter((f) => f.submittedBy === userId)
    } else if (userType === "admin") {
      // Admins can see all citizen feedback (but not admin-to-admin feedback)
      filteredFeedback = allFeedback.filter((f) => f.userType === "citizen")
    }

    // Apply additional filters
    if (category && category !== "All") {
      filteredFeedback = filteredFeedback.filter((f) => f.category === category)
    }

    if (status && status !== "All") {
      filteredFeedback = filteredFeedback.filter((f) => f.status.toLowerCase() === status.toLowerCase())
    }

    return new Response(
      JSON.stringify({
        feedback: filteredFeedback,
        userType,
        totalCount: filteredFeedback.length,
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json" },
      },
    )
  } catch (error) {
    console.error("Feedback GET API error:", error)
    return new Response(JSON.stringify({ error: "Failed to fetch feedback" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
