import { NextResponse } from "next/server"

export async function GET() {
  // Simulate anomaly detection data
  const anomalies = [
    {
      id: 1,
      type: "Energy Consumption",
      severity: "high",
      confidence: 94,
      location: "District 5",
      description: "Unusual spike in energy consumption detected",
      timestamp: new Date().toISOString(),
    },
  ]

  return NextResponse.json({ anomalies })
}

export async function POST(req: Request) {
  const { threshold, sensitivity } = await req.json()

  // Simulate updating detection parameters
  console.log("Updating anomaly detection:", { threshold, sensitivity })

  return NextResponse.json({ success: true })
}
