import { streamText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: Request) {
  try {
    const { messages, userType = "citizen" } = await req.json()

    const systemPrompt =
      userType === "admin"
        ? `You are a Smart City Assistant powered by ChatGPT for city administrators. You help with:
      - Advanced urban analytics and insights
      - Policy analysis and recommendations  
      - System administration guidance
      - Data interpretation and forecasting
      - Strategic city planning decisions
      - Resource allocation optimization
      - Emergency response coordination
      - Regulatory compliance assistance
      
      Provide detailed, technical, and actionable responses for city management professionals.`
        : `You are a Smart City Assistant powered by ChatGPT for citizens. You help with:
      - City services information
      - Environmental tips and advice
      - Public transportation guidance
      - Community events and programs
      - Reporting issues and concerns
      - Understanding city policies
      - Sustainability recommendations
      - General city information
      
      Provide helpful, friendly, and accessible responses for everyday citizens.`

    const result = streamText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      messages,
      temperature: 0.7,
      maxTokens: 1000,
    })

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Chat API error:", error)
    return new Response(JSON.stringify({ error: "Failed to process chat request" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    })
  }
}
