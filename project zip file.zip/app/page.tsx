"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Building,
  Users,
  Shield,
  ArrowRight,
  MapPin,
  Phone,
  Mail,
  Clock,
  Star,
  CheckCircle,
  BarChart3,
  MessageSquare,
  FileText,
  Settings,
} from "lucide-react"

const cityStats = [
  { label: "Population", value: "2.4M", icon: Users },
  { label: "Districts", value: "12", icon: MapPin },
  { label: "Services", value: "45+", icon: Settings },
  { label: "Satisfaction", value: "4.2/5", icon: Star },
]

const recentUpdates = [
  {
    title: "New Bike Lane Network Completed",
    description: "50km of new bike lanes now open across downtown area",
    date: "2 days ago",
    category: "Transportation",
  },
  {
    title: "Air Quality Improvement Initiative",
    description: "AQI improved by 15% following new environmental policies",
    date: "1 week ago",
    category: "Environment",
  },
  {
    title: "Smart Traffic System Deployed",
    description: "AI-powered traffic management reduces congestion by 20%",
    date: "2 weeks ago",
    category: "Technology",
  },
]

const quickServices = [
  { name: "Report Issue", icon: MessageSquare, description: "Report city issues or concerns" },
  { name: "Pay Bills", icon: FileText, description: "Pay utilities and city services" },
  { name: "Apply Permits", icon: CheckCircle, description: "Apply for building and business permits" },
  { name: "View Data", icon: BarChart3, description: "Access city metrics and reports" },
]

export default function HomePage() {
  const handlePortalSelect = (portal: string) => {
    // Redirect to login page
    window.location.href = "/login"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-green-50 to-blue-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                <Building className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Smart City Portal</h1>
                <p className="text-sm text-gray-600">Sustainable Urban Management</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge className="bg-green-100 text-green-800">Online</Badge>
              <div className="text-sm text-gray-600">
                <Clock className="w-4 h-4 inline mr-1" />
                24/7 Available
              </div>
              <Button onClick={() => (window.location.href = "/login")}>Login</Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Our Smart City</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Access city services, view real-time data, and engage with your community through our AI-powered sustainable
            city management platform.
          </p>

          {/* Portal Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto mb-12">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-300">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle className="text-2xl">Citizen Portal</CardTitle>
                <CardDescription className="text-base">
                  Access city services, submit feedback, and stay informed about your community
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Submit feedback and reports
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    View city metrics and data
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Access eco-advice and tips
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Chat with AI assistant
                  </li>
                </ul>
                <Button className="w-full" onClick={() => handlePortalSelect("citizen")}>
                  Enter Citizen Portal
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-green-300">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl">Admin Portal</CardTitle>
                <CardDescription className="text-base">
                  Comprehensive city management dashboard for administrators and officials
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Full city health dashboard
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Anomaly detection & alerts
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    KPI forecasting & analytics
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Policy management tools
                  </li>
                </ul>
                <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => handlePortalSelect("admin")}>
                  Enter Admin Portal
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* City Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {cityStats.map((stat, index) => (
            <Card key={index} className="text-center">
              <CardContent className="pt-6">
                <stat.icon className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Services */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle>Quick Services</CardTitle>
            <CardDescription>Access popular city services directly</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {quickServices.map((service, index) => (
                <Button key={index} variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                  <service.icon className="w-6 h-6 text-blue-600" />
                  <div className="text-center">
                    <div className="font-medium">{service.name}</div>
                    <div className="text-xs text-gray-500">{service.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Updates */}
        <Card>
          <CardHeader>
            <CardTitle>Recent City Updates</CardTitle>
            <CardDescription>Latest news and improvements in our city</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentUpdates.map((update, index) => (
                <div key={index} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{update.title}</h4>
                    <p className="text-sm text-gray-600 mt-1">{update.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className="text-xs">
                        {update.category}
                      </Badge>
                      <span className="text-xs text-gray-500">{update.date}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Building className="w-6 h-6" />
                <span className="font-bold">Smart City</span>
              </div>
              <p className="text-gray-400 text-sm">
                Building a sustainable future through technology and community engagement.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>City Dashboard</li>
                <li>Citizen Feedback</li>
                <li>Environmental Data</li>
                <li>Policy Search</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Documentation</li>
                <li>API Access</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="space-y-2 text-sm text-gray-400">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>info@smartcity.gov</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>City Hall, Main Street</span>
                </div>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 Smart City Portal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
