"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  TrendingUp,
  TrendingDown,
  BarChart3,
  Calendar,
  Target,
  Zap,
  Droplets,
  Wind,
  Car,
  Users,
  Leaf,
  Settings,
} from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"

const kpiData = [
  {
    name: "Energy Consumption",
    current: 2.4,
    unit: "GWh",
    forecast: [2.3, 2.2, 2.1, 2.0, 1.9, 1.8],
    target: 1.8,
    trend: "down",
    confidence: 87,
    icon: Zap,
    color: "text-yellow-600",
    bgColor: "bg-yellow-100",
  },
  {
    name: "Water Usage",
    current: 1.8,
    unit: "ML",
    forecast: [1.7, 1.6, 1.5, 1.4, 1.3, 1.2],
    target: 1.2,
    trend: "down",
    confidence: 92,
    icon: Droplets,
    color: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  {
    name: "Air Quality Index",
    current: 42,
    unit: "AQI",
    forecast: [40, 38, 35, 33, 30, 28],
    target: 25,
    trend: "down",
    confidence: 78,
    icon: Wind,
    color: "text-green-600",
    bgColor: "bg-green-100",
  },
  {
    name: "Traffic Density",
    current: 68,
    unit: "%",
    forecast: [66, 64, 62, 60, 58, 55],
    target: 50,
    trend: "down",
    confidence: 85,
    icon: Car,
    color: "text-red-600",
    bgColor: "bg-red-100",
  },
  {
    name: "Population Growth",
    current: 4.2,
    unit: "K/km²",
    forecast: [4.3, 4.4, 4.5, 4.6, 4.7, 4.8],
    target: 4.5,
    trend: "up",
    confidence: 94,
    icon: Users,
    color: "text-purple-600",
    bgColor: "bg-purple-100",
  },
  {
    name: "Green Coverage",
    current: 34,
    unit: "%",
    forecast: [36, 38, 40, 42, 44, 45],
    target: 50,
    trend: "up",
    confidence: 89,
    icon: Leaf,
    color: "text-emerald-600",
    bgColor: "bg-emerald-100",
  },
]

const forecastPeriods = [
  { value: "3months", label: "3 Months" },
  { value: "6months", label: "6 Months" },
  { value: "1year", label: "1 Year" },
  { value: "2years", label: "2 Years" },
]

const scenarios = [
  { value: "current", label: "Current Trends" },
  { value: "optimistic", label: "Optimistic" },
  { value: "pessimistic", label: "Pessimistic" },
  { value: "intervention", label: "With Interventions" },
]

export function KPIForecasting() {
  const [selectedPeriod, setSelectedPeriod] = useState("6months")
  const [selectedScenario, setSelectedScenario] = useState("current")
  const [selectedKPI, setSelectedKPI] = useState(null)
  const [compareScenarios, setCompareScenarios] = useState(false)
  const [selectedKPIs, setSelectedKPIs] = useState(["Energy Consumption", "Water Usage"])
  const [customTargets, setCustomTargets] = useState({})
  const [selectedKPIDetail, setSelectedKPIDetail] = useState(null)

  const getTargetStatus = (current: number, target: number, trend: string) => {
    const isOnTrack = trend === "down" ? current > target : current < target
    return isOnTrack ? "on-track" : "off-track"
  }

  const getStatusColor = (status: string) => {
    return status === "on-track" ? "text-green-600 bg-green-100" : "text-red-600 bg-red-100"
  }

  const calculateProgress = (current: number, target: number, forecast: number[]) => {
    const finalForecast = forecast[forecast.length - 1]
    const totalChange = Math.abs(target - current)
    const currentChange = Math.abs(finalForecast - current)
    return Math.min((currentChange / totalChange) * 100, 100)
  }

  const handleKPIClick = (kpi) => {
    setSelectedKPIDetail(kpi)
  }

  const handleUpdateConfiguration = () => {
    alert("Configuration updated successfully! New thresholds will be applied to future forecasts.")
    console.log("Updated thresholds:", customTargets)
  }

  const updateCustomTarget = (kpiName, newTarget) => {
    setCustomTargets((prev) => ({
      ...prev,
      [kpiName]: newTarget,
    }))
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            KPI Forecasting Dashboard
          </CardTitle>
          <CardDescription>
            AI-powered predictions for key sustainability metrics using machine learning
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Forecast Period</label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {forecastPeriods.map((period) => (
                    <SelectItem key={period.value} value={period.value}>
                      {period.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Scenario</label>
              <Select value={selectedScenario} onValueChange={setSelectedScenario}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {scenarios.map((scenario) => (
                    <SelectItem key={scenario.value} value={scenario.value}>
                      {scenario.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={compareScenarios} onCheckedChange={setCompareScenarios} />
              <span className="text-sm">Compare Scenarios</span>
            </div>
            <Button className="w-full" onClick={handleUpdateConfiguration}>
              <Settings className="w-4 h-4 mr-2" />
              Update Configuration
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {kpiData.map((kpi, index) => {
          const status = getTargetStatus(kpi.current, kpi.target, kpi.trend)
          const progress = calculateProgress(kpi.current, kpi.target, kpi.forecast)
          const finalForecast = kpi.forecast[kpi.forecast.length - 1]
          const TrendIcon = kpi.trend === "up" ? TrendingUp : TrendingDown

          return (
            <Card
              key={index}
              className="hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => handleKPIClick(kpi)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`p-2 rounded-lg ${kpi.bgColor}`}>
                      <kpi.icon className={`w-4 h-4 ${kpi.color}`} />
                    </div>
                    <div>
                      <CardTitle className="text-sm font-medium">{kpi.name}</CardTitle>
                    </div>
                  </div>
                  <Badge className={getStatusColor(status)}>{status === "on-track" ? "On Track" : "Off Track"}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Current vs Forecast */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Current</span>
                    <span className="font-bold">
                      {kpi.current} {kpi.unit}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Forecast</span>
                    <div className="flex items-center gap-1">
                      <span className="font-bold">
                        {finalForecast} {kpi.unit}
                      </span>
                      <TrendIcon className={`w-3 h-3 ${kpi.trend === "up" ? "text-red-500" : "text-green-500"}`} />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Target</span>
                    <span className="font-bold text-blue-600">
                      {kpi.target} {kpi.unit}
                    </span>
                  </div>
                </div>

                {/* Progress to Target */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Progress to Target</span>
                    <span className="text-sm">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                {/* Confidence */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Forecast Confidence</span>
                    <span className="text-sm">{kpi.confidence}%</span>
                  </div>
                  <Progress value={kpi.confidence} className="h-2" />
                </div>

                {/* Mini Chart Placeholder */}
                <div className="h-16 bg-gray-50 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-gray-400" />
                  <span className="text-xs text-gray-500 ml-2">Trend Chart</span>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Detailed Forecast */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Detailed Forecast Analysis
          </CardTitle>
          <CardDescription>Month-by-month predictions with confidence intervals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Forecast Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Metric</th>
                    <th className="text-left p-2">Current</th>
                    <th className="text-left p-2">Month 1</th>
                    <th className="text-left p-2">Month 3</th>
                    <th className="text-left p-2">Month 6</th>
                    <th className="text-left p-2">Target</th>
                    <th className="text-left p-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {kpiData.slice(0, 4).map((kpi, index) => {
                    const status = getTargetStatus(kpi.current, kpi.target, kpi.trend)
                    return (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="p-2 font-medium">{kpi.name}</td>
                        <td className="p-2">
                          {kpi.current} {kpi.unit}
                        </td>
                        <td className="p-2">
                          {kpi.forecast[0]} {kpi.unit}
                        </td>
                        <td className="p-2">
                          {kpi.forecast[2]} {kpi.unit}
                        </td>
                        <td className="p-2">
                          {kpi.forecast[5]} {kpi.unit}
                        </td>
                        <td className="p-2 text-blue-600 font-medium">
                          {kpi.target} {kpi.unit}
                        </td>
                        <td className="p-2">
                          <Badge className={getStatusColor(status)} size="sm">
                            {status === "on-track" ? "On Track" : "Needs Attention"}
                          </Badge>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            AI Recommendations
          </CardTitle>
          <CardDescription>Data-driven suggestions to achieve sustainability targets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-sm">Energy Efficiency Initiative</p>
                <p className="text-xs text-gray-600">
                  Implement smart grid technology to reduce energy consumption by 15% within 6 months
                </p>
                <Badge className="mt-1 text-xs" variant="outline">
                  High Impact
                </Badge>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-sm">Water Conservation Program</p>
                <p className="text-xs text-gray-600">
                  Deploy IoT sensors for leak detection to achieve 20% water usage reduction
                </p>
                <Badge className="mt-1 text-xs" variant="outline">
                  Medium Impact
                </Badge>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-sm">Traffic Optimization</p>
                <p className="text-xs text-gray-600">Upgrade traffic management system to reduce congestion by 25%</p>
                <Badge className="mt-1 text-xs" variant="outline">
                  High Impact
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
