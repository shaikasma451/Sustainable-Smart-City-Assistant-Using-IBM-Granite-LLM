"use client"

import { useState, useRef, useEffect } from "react"
import { useChat } from "ai/react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Bot,
  User,
  Send,
  Mic,
  Paperclip,
  MoreVertical,
  Sparkles,
  FileText,
  BarChart3,
  Lightbulb,
  MessageSquare,
  CheckCircle,
  AlertCircle,
} from "lucide-react"

interface ChatAssistantProps {
  userType?: "citizen" | "admin"
  userName?: string
  userId?: string
}

const quickActions = {
  citizen: [
    {
      icon: BarChart3,
      label: "City Stats",
      description: "Get current city metrics",
      prompt: "Show me the latest city statistics and performance metrics",
    },
    {
      icon: FileText,
      label: "Services Info",
      description: "Learn about city services",
      prompt: "What city services are available to citizens?",
    },
    {
      icon: Lightbulb,
      label: "Eco Tips",
      description: "Get sustainability advice",
      prompt: "Give me some practical tips for living more sustainably in the city",
    },
    {
      icon: Sparkles,
      label: "Report Issue",
      description: "Report a city issue",
      prompt: "I want to report an issue in my neighborhood",
    },
  ],
  admin: [
    {
      icon: BarChart3,
      label: "Generate Report",
      description: "Create analytics reports",
      prompt: "Generate a comprehensive city performance report for this month",
    },
    {
      icon: FileText,
      label: "Policy Analysis",
      description: "Analyze policy documents",
      prompt: "Help me analyze the impact of our new sustainability policy",
    },
    {
      icon: Lightbulb,
      label: "Recommendations",
      description: "Get strategic insights",
      prompt: "What are your top recommendations for improving city efficiency?",
    },
    {
      icon: Sparkles,
      label: "Forecast Trends",
      description: "Predict future metrics",
      prompt: "Show me energy consumption forecasts and trends for the next quarter",
    },
  ],
}

const feedbackCategories = [
  "Environment",
  "Transportation",
  "Waste Management",
  "Energy",
  "Water",
  "Public Safety",
  "Housing",
  "Education",
]

export function ChatAssistant({ userType = "citizen", userName = "User", userId }: ChatAssistantProps) {
  const [feedbackForm, setFeedbackForm] = useState({
    category: "",
    subject: "",
    message: "",
    priority: "medium",
  })
  const [isSubmittingFeedback, setIsSubmittingFeedback] = useState(false)
  const [feedbackSuccess, setFeedbackSuccess] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: "/api/chat",
    body: { userType },
    onError: (error) => {
      console.error("Chat error:", error)
    },
  })

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const handleQuickAction = (prompt: string) => {
    // Simulate form submission with the quick action prompt
    const syntheticEvent = {
      preventDefault: () => {},
      target: { message: { value: prompt } },
    } as any

    handleInputChange({ target: { value: prompt } } as any)
    setTimeout(() => handleSubmit(syntheticEvent), 100)
  }

  const handleFeedbackSubmit = async () => {
    if (!feedbackForm.category || !feedbackForm.subject || !feedbackForm.message) {
      alert("Please fill in all required fields")
      return
    }

    setIsSubmittingFeedback(true)

    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...feedbackForm,
          userType,
          userId,
          userName,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setFeedbackSuccess(true)
        setFeedbackForm({ category: "", subject: "", message: "", priority: "medium" })
        setTimeout(() => setFeedbackSuccess(false), 5000)
      } else {
        alert("Failed to submit feedback: " + result.error)
      }
    } catch (error) {
      console.error("Feedback submission error:", error)
      alert("Failed to submit feedback. Please try again.")
    } finally {
      setIsSubmittingFeedback(false)
    }
  }

  const currentQuickActions = quickActions[userType]

  return (
    <div className="space-y-6">
      <Tabs defaultValue="chat" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="chat">AI Assistant</TabsTrigger>
          <TabsTrigger value="feedback">Submit Feedback</TabsTrigger>
        </TabsList>

        <TabsContent value="chat" className="space-y-4">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="w-5 h-5" />
                Smart City Assistant
                <Badge className="ml-2 bg-green-100 text-green-800">Powered by ChatGPT</Badge>
              </CardTitle>
              <CardDescription>
                {userType === "admin"
                  ? "AI-powered assistant for city management and administration"
                  : "Your personal AI assistant for city services and information"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                {currentQuickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="h-auto p-4 flex flex-col items-start gap-2 hover:bg-blue-50"
                    onClick={() => handleQuickAction(action.prompt)}
                  >
                    <action.icon className="w-5 h-5 text-blue-600" />
                    <div className="text-left">
                      <div className="font-medium text-sm">{action.label}</div>
                      <div className="text-xs text-gray-500">{action.description}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Chat Interface */}
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="flex-shrink-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">City Assistant</CardTitle>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-xs text-gray-600">Online • ChatGPT-4</span>
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>

            {/* Chat Messages */}
            <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
              <div className="space-y-4">
                {messages.length === 0 && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-gray-100 text-gray-800 p-3 rounded-lg max-w-[80%]">
                      <div className="text-sm">
                        Hello {userName}! I'm your Smart City Assistant powered by ChatGPT.
                        {userType === "admin"
                          ? " I can help you with city management, analytics, policy analysis, and strategic planning. How can I assist you today?"
                          : " I can help you with city services, environmental tips, reporting issues, and general city information. What would you like to know?"}
                      </div>
                    </div>
                  </div>
                )}

                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    {message.role === "assistant" && (
                      <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                    )}

                    <div className={`max-w-[80%] ${message.role === "user" ? "order-1" : ""}`}>
                      <div
                        className={`p-3 rounded-lg ${
                          message.role === "user" ? "bg-blue-600 text-white ml-auto" : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                      </div>
                    </div>

                    {message.role === "user" && (
                      <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4 text-gray-600" />
                      </div>
                    )}
                  </div>
                ))}

                {isLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-gray-100 text-gray-800 p-3 rounded-lg">
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}

                {error && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0">
                      <AlertCircle className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-red-100 text-red-800 p-3 rounded-lg">
                      <div className="text-sm">Sorry, I'm having trouble connecting. Please try again.</div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Message Input */}
            <div className="flex-shrink-0 p-4 border-t">
              <form onSubmit={handleSubmit} className="flex items-center gap-2">
                <Button type="button" variant="ghost" size="sm">
                  <Paperclip className="w-4 h-4" />
                </Button>
                <div className="flex-1 relative">
                  <Input
                    placeholder={`Ask about ${userType === "admin" ? "city management, analytics, or policies" : "city services, issues, or information"}...`}
                    value={input}
                    onChange={handleInputChange}
                    className="pr-12"
                    disabled={isLoading}
                  />
                  <Button type="button" variant="ghost" size="sm" className="absolute right-1 top-1/2 -translate-y-1/2">
                    <Mic className="w-4 h-4" />
                  </Button>
                </div>
                <Button type="submit" disabled={!input.trim() || isLoading}>
                  <Send className="w-4 h-4" />
                </Button>
              </form>
              <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                <span>Powered by ChatGPT-4 • {userType === "admin" ? "Admin Mode" : "Citizen Mode"}</span>
                <span>Press Enter to send</span>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="feedback" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Submit Feedback
              </CardTitle>
              <CardDescription>Share your thoughts, report issues, or suggest improvements</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {feedbackSuccess && (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-green-800 font-medium">Feedback submitted successfully!</p>
                    <p className="text-green-700 text-sm">We'll review your feedback and respond accordingly.</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Category *</label>
                  <Select
                    value={feedbackForm.category}
                    onValueChange={(value) => setFeedbackForm({ ...feedbackForm, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {feedbackCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Priority</label>
                  <Select
                    value={feedbackForm.priority}
                    onValueChange={(value) => setFeedbackForm({ ...feedbackForm, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Subject *</label>
                <Input
                  placeholder="Brief description of your feedback"
                  value={feedbackForm.subject}
                  onChange={(e) => setFeedbackForm({ ...feedbackForm, subject: e.target.value })}
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Message *</label>
                <Textarea
                  placeholder="Provide detailed feedback, suggestions, or report an issue..."
                  rows={4}
                  value={feedbackForm.message}
                  onChange={(e) => setFeedbackForm({ ...feedbackForm, message: e.target.value })}
                />
              </div>

              <Button
                onClick={handleFeedbackSubmit}
                className="w-full"
                disabled={
                  isSubmittingFeedback || !feedbackForm.category || !feedbackForm.subject || !feedbackForm.message
                }
              >
                {isSubmittingFeedback ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Submit Feedback
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
