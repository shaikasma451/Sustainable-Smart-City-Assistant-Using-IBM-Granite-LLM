"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Zap,
  Droplets,
  Wind,
  Car,
  Eye,
  Bell,
  Settings,
} from "lucide-react"
import { Switch } from "@/components/ui/switch"

const anomalies = [
  {
    id: 1,
    type: "Energy Consumption",
    severity: "high",
    status: "active",
    description: "Unusual spike in energy consumption detected in District 5",
    location: "District 5, Commercial Zone",
    detectedAt: "2 hours ago",
    confidence: 94,
    impact: "High energy costs, potential equipment malfunction",
    recommendation: "Investigate HVAC systems and lighting in commercial buildings",
    icon: Zap,
    color: "text-red-600 bg-red-100",
    trend: "up",
    value: "+23%",
  },
  {
    id: 2,
    type: "Water Usage",
    severity: "medium",
    status: "investigating",
    description: "Abnormal water usage pattern in residential area",
    location: "Residential Zone B",
    detectedAt: "4 hours ago",
    confidence: 87,
    impact: "Potential water waste, increased utility costs",
    recommendation: "Check for leaks in main water lines",
    icon: Droplets,
    color: "text-yellow-600 bg-yellow-100",
    trend: "up",
    value: "+15%",
  },
  {
    id: 3,
    type: "Air Quality",
    severity: "low",
    status: "resolved",
    description: "Temporary air quality degradation near industrial area",
    location: "Industrial District",
    detectedAt: "1 day ago",
    confidence: 91,
    impact: "Minor health concerns for sensitive individuals",
    recommendation: "Monitor industrial emissions, increase air filtration",
    icon: Wind,
    color: "text-green-600 bg-green-100",
    trend: "down",
    value: "-8%",
  },
  {
    id: 4,
    type: "Traffic Flow",
    severity: "medium",
    status: "active",
    description: "Unusual traffic congestion pattern detected",
    location: "Main Street Corridor",
    detectedAt: "30 minutes ago",
    confidence: 89,
    impact: "Increased commute times, higher emissions",
    recommendation: "Adjust traffic light timing, consider alternate routes",
    icon: Car,
    color: "text-yellow-600 bg-yellow-100",
    trend: "up",
    value: "+18%",
  },
]

const monitoringMetrics = [
  {
    name: "Energy Systems",
    monitored: 156,
    anomalies: 3,
    uptime: 99.2,
    icon: Zap,
    color: "text-yellow-600",
  },
  {
    name: "Water Infrastructure",
    monitored: 89,
    anomalies: 1,
    uptime: 99.8,
    icon: Droplets,
    color: "text-blue-600",
  },
  {
    name: "Air Quality Sensors",
    monitored: 45,
    anomalies: 0,
    uptime: 98.9,
    icon: Wind,
    color: "text-green-600",
  },
  {
    name: "Traffic Systems",
    monitored: 234,
    anomalies: 2,
    uptime: 99.5,
    icon: Car,
    color: "text-red-600",
  },
]

export function AnomalyDetection() {
  const [selectedSeverity, setSelectedSeverity] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [realTimeMode, setRealTimeMode] = useState(false)
  const [alertSettings, setAlertSettings] = useState({
    email: true,
    sms: false,
    push: true,
  })
  const [customThresholds, setCustomThresholds] = useState({
    energy: 15,
    water: 12,
    air: 50,
    traffic: 20,
  })

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "text-red-600 bg-red-100"
      case "medium":
        return "text-yellow-600 bg-yellow-100"
      case "low":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "text-red-600 bg-red-100"
      case "investigating":
        return "text-blue-600 bg-blue-100"
      case "resolved":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return AlertTriangle
      case "investigating":
        return Clock
      case "resolved":
        return CheckCircle
      default:
        return AlertTriangle
    }
  }

  const filteredAnomalies = anomalies.filter((anomaly) => {
    const matchesSeverity = selectedSeverity === "all" || anomaly.severity === selectedSeverity
    const matchesStatus = selectedStatus === "all" || anomaly.status === selectedStatus
    return matchesSeverity && matchesStatus
  })

  const handleStatusChange = (anomalyId, newStatus) => {
    const anomaly = anomalies.find((a) => a.id === anomalyId)
    if (anomaly) {
      anomaly.status = newStatus
      alert(`Anomaly ${anomalyId} status updated to: ${newStatus}`)
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="anomalies" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="anomalies">Active Anomalies</TabsTrigger>
          <TabsTrigger value="monitoring">System Monitoring</TabsTrigger>
        </TabsList>

        <TabsContent value="anomalies" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Anomaly Detection Dashboard
              </CardTitle>
              <CardDescription>AI-powered detection of unusual patterns in city infrastructure</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <div className="flex gap-2">
                  <Button
                    variant={selectedSeverity === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedSeverity("all")}
                  >
                    All Severity
                  </Button>
                  <Button
                    variant={selectedSeverity === "high" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedSeverity("high")}
                  >
                    High
                  </Button>
                  <Button
                    variant={selectedSeverity === "medium" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedSeverity("medium")}
                  >
                    Medium
                  </Button>
                  <Button
                    variant={selectedSeverity === "low" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedSeverity("low")}
                  >
                    Low
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={selectedStatus === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedStatus("all")}
                  >
                    All Status
                  </Button>
                  <Button
                    variant={selectedStatus === "active" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedStatus("active")}
                  >
                    Active
                  </Button>
                  <Button
                    variant={selectedStatus === "investigating" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedStatus("investigating")}
                  >
                    Investigating
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Anomalies List */}
          <div className="space-y-4">
            {filteredAnomalies.map((anomaly) => {
              const StatusIcon = getStatusIcon(anomaly.status)
              const TrendIcon = anomaly.trend === "up" ? TrendingUp : TrendingDown

              return (
                <Card key={anomaly.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${anomaly.color}`}>
                          <anomaly.icon className="w-5 h-5" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{anomaly.type}</CardTitle>
                          <CardDescription className="flex items-center gap-2 mt-1">
                            <span>{anomaly.location}</span>
                            <span>•</span>
                            <span>{anomaly.detectedAt}</span>
                          </CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getSeverityColor(anomaly.severity)}>{anomaly.severity}</Badge>
                        <Badge className={getStatusColor(anomaly.status)}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {anomaly.status}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-gray-700">{anomaly.description}</p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Confidence Level</span>
                            <span className="text-sm">{anomaly.confidence}%</span>
                          </div>
                          <Progress value={anomaly.confidence} className="h-2" />
                        </div>

                        <div className="flex items-center gap-2">
                          <TrendIcon
                            className={`w-4 h-4 ${anomaly.trend === "up" ? "text-red-500" : "text-green-500"}`}
                          />
                          <span className={`font-medium ${anomaly.trend === "up" ? "text-red-500" : "text-green-500"}`}>
                            {anomaly.value}
                          </span>
                          <span className="text-sm text-gray-600">from baseline</span>
                        </div>
                      </div>

                      <div className="bg-gray-50 p-3 rounded-lg">
                        <h4 className="font-medium text-sm mb-1">Impact Assessment</h4>
                        <p className="text-sm text-gray-700">{anomaly.impact}</p>
                      </div>

                      <div className="bg-blue-50 p-3 rounded-lg">
                        <h4 className="font-medium text-sm mb-1">AI Recommendation</h4>
                        <p className="text-sm text-gray-700">{anomaly.recommendation}</p>
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          View Details
                        </Button>
                        <Button variant="outline" size="sm">
                          <Bell className="w-4 h-4 mr-1" />
                          Set Alert
                        </Button>
                        {anomaly.status === "active" && (
                          <Button size="sm" onClick={() => handleStatusChange(anomaly.id, "investigating")}>
                            Mark as Investigating
                          </Button>
                        )}
                        {anomaly.status === "investigating" && (
                          <Button size="sm" onClick={() => handleStatusChange(anomaly.id, "resolved")}>
                            Mark as Resolved
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-4">
          {/* System Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {monitoringMetrics.map((metric, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{metric.name}</CardTitle>
                  <metric.icon className={`w-4 h-4 ${metric.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-600">Monitored</span>
                      <span className="text-sm font-medium">{metric.monitored}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-600">Anomalies</span>
                      <Badge variant={metric.anomalies > 0 ? "destructive" : "secondary"} className="text-xs">
                        {metric.anomalies}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-600">Uptime</span>
                      <span className="text-sm font-medium">{metric.uptime}%</span>
                    </div>
                    <Progress value={metric.uptime} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Detection Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Detection Configuration
              </CardTitle>
              <CardDescription>Configure AI model sensitivity and alert thresholds</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <Switch checked={realTimeMode} onCheckedChange={setRealTimeMode} />
                  <span className="text-sm">Real-time Monitoring</span>
                  {realTimeMode && <Badge className="text-xs bg-green-100 text-green-600">Live</Badge>}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Energy Anomaly Threshold</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min="5"
                        max="30"
                        value={customThresholds.energy}
                        onChange={(e) =>
                          setCustomThresholds((prev) => ({ ...prev, energy: Number.parseInt(e.target.value) }))
                        }
                        className="flex-1"
                      />
                      <span className="text-sm w-12">{customThresholds.energy}%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Water Usage Sensitivity</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min="5"
                        max="30"
                        value={customThresholds.water}
                        onChange={(e) =>
                          setCustomThresholds((prev) => ({ ...prev, water: Number.parseInt(e.target.value) }))
                        }
                        className="flex-1"
                      />
                      <span className="text-sm w-12">{customThresholds.water}%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Air Quality Alert Level</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min="30"
                        max="70"
                        value={customThresholds.air}
                        onChange={(e) =>
                          setCustomThresholds((prev) => ({ ...prev, air: Number.parseInt(e.target.value) }))
                        }
                        className="flex-1"
                      />
                      <span className="text-sm w-12">AQI {customThresholds.air}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Traffic Congestion Threshold</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min="5"
                        max="40"
                        value={customThresholds.traffic}
                        onChange={(e) =>
                          setCustomThresholds((prev) => ({ ...prev, traffic: Number.parseInt(e.target.value) }))
                        }
                        className="flex-1"
                      />
                      <span className="text-sm w-12">{customThresholds.traffic}%</span>
                    </div>
                  </div>
                </div>
                <Button className="w-full">
                  <Settings className="w-4 h-4 mr-2" />
                  Update Configuration
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
