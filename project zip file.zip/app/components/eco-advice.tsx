"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Leaf, Lightbulb, Droplets, Recycle, Car, Award, Target, Calendar } from "lucide-react"

const ecoTips = [
  {
    id: 1,
    category: "Energy",
    title: "Switch to LED Lighting",
    description: "Replace incandescent bulbs with LED lights to reduce energy consumption by up to 80%.",
    impact: "High",
    difficulty: "Easy",
    savings: "$120/year",
    co2Reduction: "450 kg/year",
    icon: Lightbulb,
    color: "text-yellow-600 bg-yellow-100",
  },
  {
    id: 2,
    category: "Water",
    title: "Install Low-Flow Fixtures",
    description: "Use low-flow showerheads and faucets to reduce water usage by 30-50%.",
    impact: "Medium",
    difficulty: "Medium",
    savings: "$85/year",
    co2Reduction: "200 kg/year",
    icon: Droplets,
    color: "text-blue-600 bg-blue-100",
  },
  {
    id: 3,
    category: "Transportation",
    title: "Use Public Transport",
    description: "Take public transport or bike to work 3 days a week to reduce carbon footprint.",
    impact: "High",
    difficulty: "Easy",
    savings: "$200/month",
    co2Reduction: "1200 kg/year",
    icon: Car,
    color: "text-green-600 bg-green-100",
  },
  {
    id: 4,
    category: "Waste",
    title: "Start Composting",
    description: "Compost organic waste to reduce landfill contribution and create nutrient-rich soil.",
    impact: "Medium",
    difficulty: "Medium",
    savings: "$50/year",
    co2Reduction: "300 kg/year",
    icon: Recycle,
    color: "text-purple-600 bg-purple-100",
  },
]

const personalizedGoals = [
  {
    title: "Reduce Energy Consumption",
    current: 65,
    target: 80,
    unit: "%",
    deadline: "2024-06-30",
  },
  {
    title: "Water Conservation",
    current: 45,
    target: 60,
    unit: "%",
    deadline: "2024-08-15",
  },
  {
    title: "Waste Reduction",
    current: 30,
    target: 50,
    unit: "%",
    deadline: "2024-12-31",
  },
]

const achievements = [
  { title: "Energy Saver", description: "Reduced energy consumption by 20%", earned: true },
  { title: "Water Guardian", description: "Saved 1000L of water this month", earned: true },
  { title: "Green Commuter", description: "Used public transport 15 days", earned: false },
  { title: "Waste Warrior", description: "Recycled 50kg of materials", earned: true },
]

export function EcoAdvice() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")
  const [userGoals, setUserGoals] = useState(personalizedGoals)
  const [completedTips, setCompletedTips] = useState([])
  const [userProfile, setUserProfile] = useState({
    householdSize: 4,
    homeType: "apartment",
    transportMode: "car",
    energySource: "mixed",
  })

  const categories = ["All", "Energy", "Water", "Transportation", "Waste"]

  const filteredTips = ecoTips.filter((tip) => {
    const matchesCategory = selectedCategory === "All" || tip.category === selectedCategory
    const matchesSearch =
      tip.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tip.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "High":
        return "text-red-600 bg-red-100"
      case "Medium":
        return "text-yellow-600 bg-yellow-100"
      case "Low":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "text-green-600 bg-green-100"
      case "Medium":
        return "text-yellow-600 bg-yellow-100"
      case "Hard":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const handleStartTip = (tipId) => {
    const tip = ecoTips.find((t) => t.id === tipId)
    if (tip) {
      // Add to user's active tips
      alert(`Started: ${tip.title}. You'll receive reminders and progress tracking.`)
      setCompletedTips((prev) => [...prev, tipId])
    }
  }

  const updateGoalProgress = (goalIndex, newProgress) => {
    setUserGoals((prev) => prev.map((goal, index) => (index === goalIndex ? { ...goal, current: newProgress } : goal)))
  }

  return (
    <div className="space-y-6">
      {/* Search and Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Leaf className="w-5 h-5" />
            Personalized Eco-Advice
          </CardTitle>
          <CardDescription>AI-powered sustainability recommendations tailored to your lifestyle</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <Input
              placeholder="Search eco tips..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Eco Tips Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredTips.map((tip) => (
          <Card key={tip.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${tip.color}`}>
                    <tip.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{tip.title}</CardTitle>
                    <Badge variant="outline" className="mt-1">
                      {tip.category}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-4">{tip.description}</p>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-sm text-gray-600">Annual Savings</p>
                  <p className="font-bold text-green-600">{tip.savings}</p>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600">CO₂ Reduction</p>
                  <p className="font-bold text-blue-600">{tip.co2Reduction}</p>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  <Badge className={getImpactColor(tip.impact)}>{tip.impact} Impact</Badge>
                  <Badge className={getDifficultyColor(tip.difficulty)}>{tip.difficulty}</Badge>
                </div>
                <Button size="sm" onClick={() => handleStartTip(tip.id)} disabled={completedTips.includes(tip.id)}>
                  {completedTips.includes(tip.id) ? "Started" : "Start Now"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Personal Goals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Your Sustainability Goals
          </CardTitle>
          <CardDescription>Track your progress towards environmental targets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {personalizedGoals.map((goal, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{goal.title}</span>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">{goal.deadline}</span>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Progress value={(goal.current / goal.target) * 100} className="flex-1" />
                  <span className="text-sm font-medium">
                    {goal.current}
                    {goal.unit} / {goal.target}
                    {goal.unit}
                  </span>
                </div>
                <div className="flex gap-1 mt-1">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => updateGoalProgress(index, Math.min(goal.current + 5, goal.target))}
                  >
                    +5%
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => updateGoalProgress(index, Math.max(goal.current - 5, 0))}
                  >
                    -5%
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5" />
            Eco Achievements
          </CardTitle>
          <CardDescription>Your sustainability milestones and badges</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border-2 ${
                  achievement.earned ? "border-green-200 bg-green-50" : "border-gray-200 bg-gray-50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`p-2 rounded-full ${
                      achievement.earned ? "bg-green-500 text-white" : "bg-gray-300 text-gray-600"
                    }`}
                  >
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-medium">{achievement.title}</h4>
                    <p className="text-sm text-gray-600">{achievement.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
