"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, FileText, Calendar, Download, Eye, Star, Filter, Building, Zap } from "lucide-react"

const policyDocuments = [
  {
    id: 1,
    title: "Sustainable Energy Policy 2024",
    description: "Comprehensive framework for renewable energy adoption and carbon neutrality goals",
    category: "Energy",
    department: "Environmental Affairs",
    lastUpdated: "2024-01-15",
    status: "Active",
    relevanceScore: 95,
    tags: ["renewable energy", "carbon neutral", "solar power", "wind energy"],
    summary:
      "This policy establishes the city's commitment to achieving carbon neutrality by 2030 through renewable energy adoption, energy efficiency programs, and sustainable infrastructure development.",
    keyPoints: [
      "Mandate 80% renewable energy by 2028",
      "Incentives for solar panel installation",
      "Energy efficiency standards for buildings",
    ],
  },
  {
    id: 2,
    title: "Water Conservation Guidelines",
    description: "Municipal water usage regulations and conservation strategies",
    category: "Water Management",
    department: "Public Works",
    lastUpdated: "2023-11-20",
    status: "Active",
    relevanceScore: 88,
    tags: ["water conservation", "drought management", "irrigation", "recycling"],
    summary:
      "Guidelines for water conservation including usage restrictions, recycling programs, and drought management protocols.",
    keyPoints: [
      "Mandatory water recycling for large buildings",
      "Drought response protocols",
      "Incentives for water-efficient landscaping",
    ],
  },
  {
    id: 3,
    title: "Green Transportation Initiative",
    description: "Public transport electrification and sustainable mobility framework",
    category: "Transportation",
    department: "Transportation",
    lastUpdated: "2024-02-10",
    status: "Draft",
    relevanceScore: 92,
    tags: ["electric vehicles", "public transport", "bike lanes", "emissions"],
    summary:
      "Initiative to electrify public transportation, expand bike infrastructure, and reduce vehicle emissions through various incentive programs.",
    keyPoints: [
      "Electrify 100% of bus fleet by 2026",
      "Expand bike lane network by 50%",
      "EV charging station requirements",
    ],
  },
  {
    id: 4,
    title: "Waste Management Reform Act",
    description: "Comprehensive waste reduction and recycling policy framework",
    category: "Waste Management",
    department: "Environmental Services",
    lastUpdated: "2023-12-05",
    status: "Active",
    relevanceScore: 85,
    tags: ["recycling", "composting", "waste reduction", "circular economy"],
    summary:
      "Reform act establishing new waste reduction targets, mandatory composting programs, and circular economy principles.",
    keyPoints: [
      "Mandatory composting for all residents",
      "50% waste reduction target by 2027",
      "Extended producer responsibility programs",
    ],
  },
]

const categories = [
  "All",
  "Energy",
  "Water Management",
  "Transportation",
  "Waste Management",
  "Housing",
  "Economic Development",
]
const departments = [
  "All",
  "Environmental Affairs",
  "Public Works",
  "Transportation",
  "Environmental Services",
  "Planning",
]
const statuses = ["All", "Active", "Draft", "Under Review", "Archived"]

export function PolicySearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedDepartment, setSelectedDepartment] = useState("All")
  const [selectedStatus, setSelectedStatus] = useState("All")
  const [searchResults, setSearchResults] = useState(policyDocuments)

  const [searchHistory, setSearchHistory] = useState([])
  const [savedSearches, setSavedSearches] = useState([])
  const [searchFilters, setSearchFilters] = useState({
    dateRange: "all",
    relevanceThreshold: 70,
    includeArchived: false,
  })

  const handleSearch = () => {
    let filtered = policyDocuments

    if (searchQuery) {
      filtered = filtered.filter(
        (doc) =>
          doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          doc.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          doc.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    }

    if (selectedCategory !== "All") {
      filtered = filtered.filter((doc) => doc.category === selectedCategory)
    }

    if (selectedDepartment !== "All") {
      filtered = filtered.filter((doc) => doc.department === selectedDepartment)
    }

    if (selectedStatus !== "All") {
      filtered = filtered.filter((doc) => doc.status === selectedStatus)
    }

    // Sort by relevance score
    filtered.sort((a, b) => b.relevanceScore - a.relevanceScore)

    setSearchResults(filtered)
  }

  const handleAdvancedSearch = async () => {
    if (!searchQuery.trim()) return

    setSearchHistory((prev) => [searchQuery, ...prev.slice(0, 9)]) // Keep last 10 searches

    try {
      const response = await fetch("/api/policy-search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: searchQuery,
          category: selectedCategory,
          department: selectedDepartment,
          status: selectedStatus,
          filters: searchFilters,
        }),
      })

      const data = await response.json()
      setSearchResults(data.results || policyDocuments)
    } catch (error) {
      console.error("Search failed:", error)
      handleSearch() // Fallback to local search
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "text-green-600 bg-green-100"
      case "Draft":
        return "text-yellow-600 bg-yellow-100"
      case "Under Review":
        return "text-blue-600 bg-blue-100"
      case "Archived":
        return "text-gray-600 bg-gray-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Energy":
        return Zap
      case "Water Management":
        return "Droplets"
      case "Transportation":
        return "Car"
      case "Waste Management":
        return "Recycle"
      default:
        return FileText
    }
  }

  const [semanticQuery, setSemanticQuery] = useState("")
  const [semanticResults, setSemanticResults] = useState([])

  const handleSemanticSearch = async () => {
    if (!semanticQuery.trim()) return

    try {
      const response = await fetch("/api/semantic-search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: semanticQuery }),
      })

      const data = await response.json()
      setSemanticResults(data.results || [])
    } catch (error) {
      console.error("Semantic search failed:", error)
    }
  }

  const handleExampleQuery = (query) => {
    setSemanticQuery(query)
    handleSemanticSearch()
  }

  const handleViewDocument = (docId) => {
    alert(`Opening document ${docId} in viewer...`)
    // In real app, would open document viewer
  }

  const handleDownloadDocument = (docId) => {
    alert(`Downloading document ${docId}...`)
    // In real app, would trigger download
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="search" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="search">Policy Search</TabsTrigger>
          <TabsTrigger value="semantic">Semantic Search</TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-4">
          {/* Search Interface */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Policy Document Search
              </CardTitle>
              <CardDescription>
                Search through municipal policies and regulations using AI-powered semantic search
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Search Bar */}
              <div className="flex gap-2">
                <Input
                  placeholder="Search policies, regulations, or use natural language queries..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1"
                  onKeyPress={(e) => e.key === "Enter" && handleAdvancedSearch()}
                />
                <Button onClick={handleAdvancedSearch}>
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>

              {/* Filters */}
              <div className="flex gap-4 flex-wrap">
                <div className="flex gap-2">
                  <Filter className="w-4 h-4 mt-1 text-gray-500" />
                  <span className="text-sm font-medium">Filters:</span>
                </div>

                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="text-sm border rounded px-2 py-1"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedDepartment}
                  onChange={(e) => setSelectedDepartment(e.target.value)}
                  className="text-sm border rounded px-2 py-1"
                >
                  {departments.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="text-sm border rounded px-2 py-1"
                >
                  {statuses.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Relevance Threshold</label>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={searchFilters.relevanceThreshold}
                  onChange={(e) =>
                    setSearchFilters((prev) => ({ ...prev, relevanceThreshold: Number.parseInt(e.target.value) }))
                  }
                  className="w-full"
                />
                <span className="text-xs text-gray-500">{searchFilters.relevanceThreshold}% minimum relevance</span>
              </div>
            </CardContent>
          </Card>

          {/* Search Results */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Search Results ({searchResults.length})</h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Sort by Relevance
                </Button>
                <Button variant="outline" size="sm">
                  Sort by Date
                </Button>
              </div>
            </div>

            {searchResults.map((doc) => (
              <Card key={doc.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <FileText className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{doc.title}</CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          <Building className="w-3 h-3" />
                          <span>{doc.department}</span>
                          <span>•</span>
                          <Calendar className="w-3 h-3" />
                          <span>Updated {doc.lastUpdated}</span>
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(doc.status)}>{doc.status}</Badge>
                      <div className="flex items-center gap-1 text-sm text-gray-600">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span>{doc.relevanceScore}%</span>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-gray-700">{doc.description}</p>

                    <div className="bg-gray-50 p-3 rounded-lg">
                      <h4 className="font-medium text-sm mb-2">AI Summary</h4>
                      <p className="text-sm text-gray-700">{doc.summary}</p>
                    </div>

                    <div>
                      <h4 className="font-medium text-sm mb-2">Key Points</h4>
                      <ul className="space-y-1">
                        {doc.keyPoints.map((point, index) => (
                          <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                            <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></span>
                            {point}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex gap-2">
                        <Badge variant="outline">{doc.category}</Badge>
                        {doc.tags.slice(0, 3).map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {doc.tags.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{doc.tags.length - 3} more
                          </Badge>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleViewDocument(doc.id)}>
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDownloadDocument(doc.id)}>
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="semantic" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5" />
                Semantic Policy Search
              </CardTitle>
              <CardDescription>
                Use natural language to find relevant policies using Pinecone vector database
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Natural Language Query</label>
                  <Input
                    placeholder="e.g., 'What are the rules about solar panels on residential buildings?'"
                    className="w-full"
                    value={semanticQuery}
                    onChange={(e) => setSemanticQuery(e.target.value)}
                  />
                </div>

                <Button className="w-full" onClick={handleSemanticSearch}>
                  <Search className="w-4 h-4 mr-2" />
                  Search with AI
                </Button>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-sm mb-2">Example Queries</h4>
                <div className="space-y-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="justify-start h-auto p-2 text-left"
                    onClick={() => handleExampleQuery("What incentives are available for electric vehicle adoption?")}
                  >
                    "What incentives are available for electric vehicle adoption?"
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="justify-start h-auto p-2 text-left"
                    onClick={() => handleExampleQuery("How can businesses reduce their water consumption?")}
                  >
                    "How can businesses reduce their water consumption?"
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="justify-start h-auto p-2 text-left"
                    onClick={() => handleExampleQuery("What are the requirements for green building certification?")}
                  >
                    "What are the requirements for green building certification?"
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
