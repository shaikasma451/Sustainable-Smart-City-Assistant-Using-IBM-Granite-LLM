"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { FileText, Upload, Download, Clock, CheckCircle, AlertCircle, Sparkles, Eye, Copy } from "lucide-react"

const documentHistory = [
  {
    id: 1,
    title: "City Budget Report 2024",
    type: "PDF",
    size: "2.4 MB",
    status: "completed",
    summary:
      "The 2024 city budget allocates $45M for infrastructure, with 30% dedicated to green initiatives. Key investments include renewable energy projects and public transportation expansion.",
    keyPoints: [
      "Infrastructure budget increased by 15%",
      "Green initiatives receive $13.5M funding",
      "Public transport expansion planned for Q2",
    ],
    uploadedAt: "2 hours ago",
    processingTime: "45 seconds",
  },
  {
    id: 2,
    title: "Environmental Impact Assessment",
    type: "DOCX",
    size: "1.8 MB",
    status: "processing",
    summary: "",
    keyPoints: [],
    uploadedAt: "10 minutes ago",
    processingTime: "In progress...",
  },
  {
    id: 3,
    title: "Traffic Management Policy",
    type: "PDF",
    size: "3.1 MB",
    status: "completed",
    summary:
      "New traffic management policies focus on reducing congestion through smart traffic lights and dynamic routing. Expected to reduce travel time by 20% in peak hours.",
    keyPoints: [
      "Smart traffic light implementation",
      "Dynamic routing system deployment",
      "20% reduction in peak hour travel time",
    ],
    uploadedAt: "1 day ago",
    processingTime: "1 minute 12 seconds",
  },
]

export function DocumentSummarization() {
  const [inputText, setInputText] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [summary, setSummary] = useState("")
  const [uploadedFiles, setUploadedFiles] = useState([])

  const handleTextSummarization = async () => {
    if (!inputText.trim()) return

    setIsProcessing(true)
    try {
      const response = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: inputText }),
      })

      const data = await response.json()
      setSummary(data.summary)
    } catch (error) {
      console.error("Summarization failed:", error)
      setSummary("Error: Failed to generate summary. Please try again.")
    } finally {
      setIsProcessing(false)
    }
  }

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files)
    files.forEach((file) => {
      const newDoc = {
        id: Date.now() + Math.random(),
        title: file.name,
        type: file.name.split(".").pop().toUpperCase(),
        size: (file.size / 1024 / 1024).toFixed(1) + " MB",
        status: "processing",
        uploadedAt: "Just now",
        processingTime: "Processing...",
      }
      setUploadedFiles((prev) => [newDoc, ...prev])

      // Simulate processing
      setTimeout(() => {
        newDoc.status = "completed"
        newDoc.processingTime = "45 seconds"
        newDoc.summary = "AI-generated summary of the uploaded document."
        newDoc.keyPoints = ["Key insight 1", "Key insight 2", "Key insight 3"]
        setUploadedFiles((prev) => [...prev])
      }, 3000)
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "text-green-600 bg-green-100"
      case "processing":
        return "text-blue-600 bg-blue-100"
      case "failed":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return CheckCircle
      case "processing":
        return Clock
      case "failed":
        return AlertCircle
      default:
        return FileText
    }
  }

  return (
    <div className="space-y-6">
      {/* Text Summarization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Text Summarization
          </CardTitle>
          <CardDescription>Paste text content for AI-powered summarization using IBM Granite LLM</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Paste your document text here for summarization..."
            rows={6}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          />
          <Button onClick={handleTextSummarization} disabled={!inputText.trim() || isProcessing} className="w-full">
            {isProcessing ? (
              <>
                <Clock className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Summary
              </>
            )}
          </Button>

          {isProcessing && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Processing with IBM Granite LLM...</span>
                <span>75%</span>
              </div>
              <Progress value={75} className="h-2" />
            </div>
          )}

          {summary && (
            <Card className="bg-blue-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-lg">AI-Generated Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{summary}</p>
                <div className="flex gap-2 mt-4">
                  <Button variant="outline" size="sm">
                    <Copy className="w-4 h-4 mr-1" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-1" />
                    Export
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {/* Document Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Document Upload
          </CardTitle>
          <CardDescription>Upload PDF, DOCX, or TXT files for automatic summarization</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
            <input
              type="file"
              multiple
              accept=".pdf,.docx,.txt"
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-600 mb-2">Drop files here or click to upload</p>
              <p className="text-sm text-gray-500">Supports PDF, DOCX, TXT files up to 10MB</p>
            </label>
          </div>
        </CardContent>
      </Card>

      {/* Document History */}
      <Card>
        <CardHeader>
          <CardTitle>Processing History</CardTitle>
          <CardDescription>Recently processed documents and their summaries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {documentHistory.map((doc) => {
              const StatusIcon = getStatusIcon(doc.status)
              return (
                <Card key={doc.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <FileText className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{doc.title}</CardTitle>
                          <CardDescription className="flex items-center gap-2 mt-1">
                            <span>{doc.type}</span>
                            <span>•</span>
                            <span>{doc.size}</span>
                            <span>•</span>
                            <span>{doc.uploadedAt}</span>
                          </CardDescription>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(doc.status)}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {doc.status}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>

                  {doc.status === "completed" && (
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <h4 className="font-medium text-sm mb-2">Summary</h4>
                          <p className="text-gray-700 text-sm">{doc.summary}</p>
                        </div>

                        <div>
                          <h4 className="font-medium text-sm mb-2">Key Points</h4>
                          <ul className="space-y-1">
                            {doc.keyPoints.map((point, index) => (
                              <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></span>
                                {point}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex gap-2 pt-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4 mr-1" />
                            View Full
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4 mr-1" />
                            Export
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  )}

                  {doc.status === "processing" && (
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Processing with IBM Granite LLM...</span>
                          <span>Processing time: {doc.processingTime}</span>
                        </div>
                        <Progress value={65} className="h-2" />
                      </div>
                    </CardContent>
                  )}
                </Card>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
