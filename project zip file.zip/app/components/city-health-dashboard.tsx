"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Zap,
  Droplets,
  Wind,
  Thermometer,
  Car,
  TreePine,
  Recycle,
  Users,
  TrendingUp,
  TrendingDown,
  RefreshCw,
} from "lucide-react"
import { useState } from "react"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const cityMetrics = [
  {
    title: "Energy Consumption",
    value: "2.4 GWh",
    change: -12,
    icon: Zap,
    color: "text-yellow-600",
    bgColor: "bg-yellow-100",
    progress: 76,
  },
  {
    title: "Water Usage",
    value: "1.8M L",
    change: -8,
    icon: Droplets,
    color: "text-blue-600",
    bgColor: "bg-blue-100",
    progress: 64,
  },
  {
    title: "Air Quality Index",
    value: "42 AQI",
    change: 15,
    icon: Wind,
    color: "text-green-600",
    bgColor: "bg-green-100",
    progress: 85,
  },
  {
    title: "Average Temperature",
    value: "22°C",
    change: 2,
    icon: Thermometer,
    color: "text-orange-600",
    bgColor: "bg-orange-100",
    progress: 68,
  },
  {
    title: "Traffic Density",
    value: "68%",
    change: -5,
    icon: Car,
    color: "text-red-600",
    bgColor: "bg-red-100",
    progress: 68,
  },
  {
    title: "Green Coverage",
    value: "34%",
    change: 8,
    icon: TreePine,
    color: "text-emerald-600",
    bgColor: "bg-emerald-100",
    progress: 34,
  },
  {
    title: "Waste Recycled",
    value: "78%",
    change: 12,
    icon: Recycle,
    color: "text-purple-600",
    bgColor: "bg-purple-100",
    progress: 78,
  },
  {
    title: "Population Density",
    value: "4.2K/km²",
    change: 3,
    icon: Users,
    color: "text-indigo-600",
    bgColor: "bg-indigo-100",
    progress: 82,
  },
]

const sustainabilityGoals = [
  { goal: "Carbon Neutral by 2030", progress: 45, status: "On Track" },
  { goal: "Renewable Energy 80%", progress: 62, status: "Ahead" },
  { goal: "Waste Reduction 50%", progress: 38, status: "Behind" },
  { goal: "Green Transport 60%", progress: 28, status: "Behind" },
]

export function CityHealthDashboard() {
  const [selectedTimeRange, setSelectedTimeRange] = useState("24h")
  const [selectedDistrict, setSelectedDistrict] = useState("All")
  const [autoRefresh, setAutoRefresh] = useState(true)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-4">
          <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">Last Hour</SelectItem>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Districts</SelectItem>
              <SelectItem value="District 1">District 1</SelectItem>
              <SelectItem value="District 2">District 2</SelectItem>
              <SelectItem value="District 3">District 3</SelectItem>
              <SelectItem value="District 4">District 4</SelectItem>
              <SelectItem value="District 5">District 5</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <Switch checked={autoRefresh} onCheckedChange={setAutoRefresh} />
          <span className="text-sm">Auto-refresh</span>
          <Button variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-1" />
            Refresh
          </Button>
        </div>
      </div>
      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cityMetrics.map((metric, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{metric.title}</CardTitle>
              <div className={`p-2 rounded-lg ${metric.bgColor}`}>
                <metric.icon className={`w-4 h-4 ${metric.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-2">{metric.value}</div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  {metric.change > 0 ? (
                    <TrendingUp className="w-3 h-3 text-green-500" />
                  ) : (
                    <TrendingDown className="w-3 h-3 text-red-500" />
                  )}
                  <span className={`text-xs ${metric.change > 0 ? "text-green-500" : "text-red-500"}`}>
                    {Math.abs(metric.change)}%
                  </span>
                </div>
                <Progress value={metric.progress} className="w-16 h-2" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Sustainability Goals */}
      <Card>
        <CardHeader>
          <CardTitle>Sustainability Goals 2030</CardTitle>
          <CardDescription>Track progress towards city-wide sustainability targets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sustainabilityGoals.map((goal, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{goal.goal}</span>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        goal.status === "On Track" ? "default" : goal.status === "Ahead" ? "secondary" : "destructive"
                      }
                      className="text-xs"
                    >
                      {goal.status}
                    </Badge>
                    <span className="text-sm text-gray-600">{goal.progress}%</span>
                  </div>
                </div>
                <Progress value={goal.progress} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Environmental Alerts</CardTitle>
          <CardDescription>AI-detected anomalies and recommendations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-sm">High Energy Consumption Detected</p>
                <p className="text-xs text-gray-600">District 5 showing 23% increase in energy usage</p>
                <p className="text-xs text-gray-500 mt-1">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-sm">Air Quality Improvement</p>
                <p className="text-xs text-gray-600">AQI improved by 15 points in downtown area</p>
                <p className="text-xs text-gray-500 mt-1">4 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-red-50 rounded-lg border border-red-200">
              <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
              <div>
                <p className="font-medium text-sm">Waste Collection Delay</p>
                <p className="text-xs text-gray-600">Route optimization needed for Zone 3</p>
                <p className="text-xs text-gray-500 mt-1">6 hours ago</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
