"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Users, TrendingUp, AlertTriangle, CheckCircle, Clock } from "lucide-react"

const categories = [
  "All",
  "Environment",
  "Transportation",
  "Waste Management",
  "Energy",
  "Water",
  "Public Safety",
  "Infrastructure",
]
const statuses = ["All", "Pending", "In Progress", "Resolved"]
const priorities = ["All", "High", "Medium", "Low"]

interface AdminFeedbackProps {
  userId?: string
  userName?: string
}

export function AdminFeedback({ userId = "admin-001", userName = "Admin User" }: AdminFeedbackProps) {
  const [allFeedback, setAllFeedback] = useState([])
  const [filteredFeedback, setFilteredFeedback] = useState([])
  const [loading, setLoading] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedStatus, setSelectedStatus] = useState("All")
  const [selectedPriority, setSelectedPriority] = useState("All")

  const fetchAllFeedback = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/feedback?userType=admin&userId=${userId}`)
      const data = await response.json()
      setAllFeedback(data.feedback || [])
      setFilteredFeedback(data.feedback || [])
    } catch (error) {
      console.error("Error fetching feedback:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchAllFeedback()
  }, [userId])

  useEffect(() => {
    let filtered = allFeedback

    if (selectedCategory !== "All") {
      filtered = filtered.filter((f) => f.category === selectedCategory)
    }

    if (selectedStatus !== "All") {
      filtered = filtered.filter((f) => f.status.toLowerCase() === selectedStatus.toLowerCase())
    }

    if (selectedPriority !== "All") {
      filtered = filtered.filter((f) => f.priority.toLowerCase() === selectedPriority.toLowerCase())
    }

    setFilteredFeedback(filtered)
  }, [allFeedback, selectedCategory, selectedStatus, selectedPriority])

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return "text-green-600 bg-green-100"
      case "negative":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "text-green-600 bg-green-100"
      case "in-progress":
        return "text-blue-600 bg-blue-100"
      case "pending":
        return "text-yellow-600 bg-yellow-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-600 bg-red-100"
      case "medium":
        return "text-yellow-600 bg-yellow-100"
      case "low":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusStats = () => {
    const pending = allFeedback.filter((f) => f.status === "pending").length
    const inProgress = allFeedback.filter((f) => f.status === "in-progress").length
    const resolved = allFeedback.filter((f) => f.status === "resolved").length
    const highPriority = allFeedback.filter((f) => f.priority === "high").length

    return { pending, inProgress, resolved, highPriority }
  }

  const stats = getStatusStats()

  const handleStatusChange = async (feedbackId: number, newStatus: string) => {
    // In a real app, this would update the database
    const updatedFeedback = allFeedback.map((f) => (f.id === feedbackId ? { ...f, status: newStatus } : f))
    setAllFeedback(updatedFeedback)
    alert(`Feedback status updated to: ${newStatus}`)
  }

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Progress</p>
                <p className="text-2xl font-bold text-blue-600">{stats.inProgress}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Resolved</p>
                <p className="text-2xl font-bold text-green-600">{stats.resolved}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">High Priority</p>
                <p className="text-2xl font-bold text-red-600">{stats.highPriority}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Citizen Feedback Management
          </CardTitle>
          <CardDescription>Review and manage feedback submitted by citizens</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex gap-4 mb-6">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                {statuses.map((status) => (
                  <SelectItem key={status} value={status}>
                    {status}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedPriority} onValueChange={setSelectedPriority}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select priority" />
              </SelectTrigger>
              <SelectContent>
                {priorities.map((priority) => (
                  <SelectItem key={priority} value={priority}>
                    {priority}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Feedback List */}
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-2 text-gray-600">Loading feedback...</p>
            </div>
          ) : filteredFeedback.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No feedback found matching your filters.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredFeedback.map((feedback) => (
                <Card key={feedback.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{feedback.subject}</CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          <span>by {feedback.citizen}</span>
                          <span>•</span>
                          <span>{new Date(feedback.timestamp).toLocaleDateString()}</span>
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={getSentimentColor(feedback.sentiment)}>{feedback.sentiment}</Badge>
                        <Badge className={getStatusColor(feedback.status)}>{feedback.status}</Badge>
                        <Badge className={getPriorityColor(feedback.priority)}>{feedback.priority}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-4">{feedback.message}</p>

                    {feedback.aiAnalysis && (
                      <div className="bg-blue-50 p-3 rounded-lg mb-4">
                        <h4 className="font-medium text-blue-900 mb-2">AI Analysis</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                          <p>
                            <strong>Suggested Department:</strong> {feedback.aiAnalysis.suggestedDepartment}
                          </p>
                          <p>
                            <strong>Estimated Resolution:</strong> {feedback.aiAnalysis.estimatedResolutionTime}
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{feedback.category}</Badge>
                      <div className="flex items-center gap-2">
                        <Select
                          value={feedback.status}
                          onValueChange={(value) => handleStatusChange(feedback.id, value)}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="in-progress">In Progress</SelectItem>
                            <SelectItem value="resolved">Resolved</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button variant="outline" size="sm">
                          <MessageSquare className="w-4 h-4 mr-1" />
                          Respond
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
