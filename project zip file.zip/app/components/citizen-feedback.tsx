"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MessageSquare, Send, Eye, Clock, CheckCircle } from "lucide-react"

const categories = [
  "Environment",
  "Transportation",
  "Waste Management",
  "Energy",
  "Water",
  "Public Safety",
  "Infrastructure",
]

interface CitizenFeedbackProps {
  userId?: string
  userName?: string
}

export function CitizenFeedback({ userId = "citizen-001", userName = "Current User" }: CitizenFeedbackProps) {
  const [myFeedback, setMyFeedback] = useState([])
  const [loading, setLoading] = useState(false)
  const [newFeedback, setNewFeedback] = useState({
    category: "",
    subject: "",
    message: "",
  })

  const fetchMyFeedback = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/feedback?userType=citizen&userId=${userId}`)
      const data = await response.json()
      setMyFeedback(data.feedback || [])
    } catch (error) {
      console.error("Error fetching feedback:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchMyFeedback()
  }, [userId])

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "positive":
        return "text-green-600 bg-green-100"
      case "negative":
        return "text-red-600 bg-red-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved":
        return "text-green-600 bg-green-100"
      case "in-progress":
        return "text-blue-600 bg-blue-100"
      case "pending":
        return "text-yellow-600 bg-yellow-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "text-red-600 bg-red-100"
      case "medium":
        return "text-yellow-600 bg-yellow-100"
      case "low":
        return "text-green-600 bg-green-100"
      default:
        return "text-gray-600 bg-gray-100"
    }
  }

  const handleSubmitFeedback = async () => {
    if (!newFeedback.category || !newFeedback.subject || !newFeedback.message) {
      alert("Please fill in all fields")
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newFeedback,
          userType: "citizen",
          userName,
          userId,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setNewFeedback({ category: "", subject: "", message: "" })
        alert(
          `Feedback submitted successfully! ${result.message}\nEstimated response time: ${result.estimatedResponse}`,
        )
        fetchMyFeedback() // Refresh the feedback list
      } else {
        alert("Failed to submit feedback: " + result.error)
      }
    } catch (error) {
      console.error("Feedback submission error:", error)
      alert("Failed to submit feedback. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="submit" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="submit">Submit Feedback</TabsTrigger>
          <TabsTrigger value="my-feedback">My Feedback ({myFeedback.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="submit" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Submit New Feedback</CardTitle>
              <CardDescription>
                Share your thoughts and suggestions to help improve our city. Your feedback will be reviewed by city
                administrators.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Category *</label>
                <Select
                  value={newFeedback.category}
                  onValueChange={(value) => setNewFeedback({ ...newFeedback, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Subject *</label>
                <Input
                  placeholder="Brief description of your feedback"
                  value={newFeedback.subject}
                  onChange={(e) => setNewFeedback({ ...newFeedback, subject: e.target.value })}
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Message *</label>
                <Textarea
                  placeholder="Provide detailed feedback, suggestions, or report issues..."
                  rows={4}
                  value={newFeedback.message}
                  onChange={(e) => setNewFeedback({ ...newFeedback, message: e.target.value })}
                />
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">What happens next?</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Your feedback will be reviewed by city administrators</li>
                  <li>• You'll receive updates on the status of your submission</li>
                  <li>• Response times vary based on priority and complexity</li>
                </ul>
              </div>

              <Button onClick={handleSubmitFeedback} className="w-full" disabled={loading}>
                <Send className="w-4 h-4 mr-2" />
                {loading ? "Submitting..." : "Submit Feedback"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="my-feedback" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                My Submitted Feedback
              </CardTitle>
              <CardDescription>Track the status of your submitted feedback and suggestions</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="mt-2 text-gray-600">Loading your feedback...</p>
                </div>
              ) : myFeedback.length === 0 ? (
                <div className="text-center py-8">
                  <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">You haven't submitted any feedback yet.</p>
                  <p className="text-sm text-gray-500 mt-1">Use the "Submit Feedback" tab to share your thoughts!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {myFeedback.map((feedback) => (
                    <Card key={feedback.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-medium text-lg">{feedback.subject}</h4>
                            <p className="text-sm text-gray-600">
                              Submitted {new Date(feedback.timestamp).toLocaleDateString()} • {feedback.category}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getStatusColor(feedback.status)}>
                              {feedback.status === "resolved" && <CheckCircle className="w-3 h-3 mr-1" />}
                              {feedback.status === "in-progress" && <Clock className="w-3 h-3 mr-1" />}
                              {feedback.status === "pending" && <Clock className="w-3 h-3 mr-1" />}
                              {feedback.status}
                            </Badge>
                            <Badge className={getPriorityColor(feedback.priority)}>{feedback.priority}</Badge>
                          </div>
                        </div>

                        <p className="text-gray-700 mb-4">{feedback.message}</p>

                        {feedback.aiAnalysis && (
                          <div className="bg-gray-50 p-3 rounded-lg">
                            <p className="text-sm text-gray-600">
                              <strong>Assigned to:</strong> {feedback.aiAnalysis.suggestedDepartment}
                            </p>
                            <p className="text-sm text-gray-600">
                              <strong>Estimated response:</strong> {feedback.aiAnalysis.estimatedResolutionTime}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
